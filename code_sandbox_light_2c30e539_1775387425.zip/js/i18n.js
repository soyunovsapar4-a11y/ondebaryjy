// =====================================================
// ÖŇDE BARYJY ÝYLADYŞHANA — i18n Translations
// Languages: ru (Russian), en (English), tk (Turkmen)
// Author: yesenow dayanc
// =====================================================

const TRANSLATIONS = {

  // ==================== RUSSIAN ====================
  ru: {
    appName:        "ÖŇDE BARYJY ÝYLADYŞHANA",
    appSub:         "Передовая теплица Центральной Азии",
    appDesc:        "Научный справочник по пестицидам, опылителям и плодовым культурам",
    tagline:        "Наука · Агрономия · Центральная Азия",

    // Nav
    nav_home:       "Главная",
    nav_pesticides: "Пестициды",
    nav_pollinators:"Опылители",
    nav_fruits:     "Культуры",
    nav_risks:      "Риски",
    nav_calc:       "Калькулятор",
    nav_archive:    "Архив",
    nav_profile:    "Профиль",
    nav_seo:        "SEO Гид",
    nav_refs:       "Источники",

    // Auth
    login:          "Войти",
    register:       "Регистрация",
    logout:         "Выйти",
    profile:        "Профиль",
    email:          "Email",
    password:       "Пароль",
    name:           "Имя",
    confirmPass:    "Подтвердите пароль",
    noAccount:      "Нет аккаунта?",
    hasAccount:     "Уже есть аккаунт?",
    forgotPass:     "Забыли пароль?",
    loginTitle:     "Добро пожаловать",
    registerTitle:  "Создать аккаунт",
    loginSuccess:   "✅ Вы вошли в систему!",
    logoutSuccess:  "👋 Вы вышли из системы",
    registerSuccess:"🎉 Аккаунт создан!",
    errEmail:       "Введите корректный email",
    errPassLen:     "Пароль минимум 6 символов",
    errPassMatch:   "Пароли не совпадают",
    errNameLen:     "Имя минимум 2 символа",
    errUserExists:  "Пользователь уже существует",
    errInvalid:     "Неверный email или пароль",

    // Hero
    hero_badge:     "🌱 Научный справочник · ЦА · 2024",
    hero_desc:      "Детальное исследование взаимодействия пестицидов с опылителями в сельском хозяйстве Центральной Азии. Данные, таблицы, калькуляторы для агрономов и фермеров.",
    hero_btn1:      "Изучить пестициды",
    hero_btn2:      "Калькулятор",
    stat1_num:      "6+",  stat1_lbl: "Классов пестицидов",
    stat2_num:      "5",   stat2_lbl: "Групп опылителей",
    stat3_num:      "26%", stat3_lbl: "Прирост урожая",
    stat4_num:      "20+", stat4_lbl: "Научных источников",

    // Pages titles
    page_pesticides:"🧪 Классы пестицидов",
    page_pollinators:"🐝 Опылители",
    page_fruits:    "🍎 Плодовые культуры",
    page_risks:     "⚠️ Риски и токсичность",
    page_calc:      "🧮 Калькулятор",
    page_archive:   "🗂️ Архив & База знаний",
    page_profile:   "👤 Профиль",
    page_seo:       "🔍 SEO Руководство",
    page_refs:      "📚 Источники",

    // Calc
    calc_title:     "Калькулятор пестицидов и опылителей",
    calc_tab1:      "Дозировка",
    calc_tab2:      "Риск для пчёл",
    calc_tab3:      "Ульи/га",
    calc_area:      "Площадь обработки (га)",
    calc_conc:      "Концентрация препарата (%)",
    calc_rate:      "Норма расхода воды (л/га)",
    calc_substance: "Действующее вещество",
    calc_dose:      "Доза д.в. (%)",
    calc_bees_exp:  "Ожидаемое воздействие (нг/пчела)",
    calc_crop:      "Культура",
    calc_yield_exp: "Ожидаемый урожай без опыления (т/га)",
    calc_btn:       "Рассчитать",
    calc_result:    "Результат:",
    calc_need_prep: "Нужно препарата:",
    calc_need_ai:   "Д.в. в рабочем растворе:",
    calc_risk_level:"Уровень риска:",
    calc_hives:     "Рекомендуемых ульев:",
    calc_yield_gain:"Прирост урожая с опылением:",

    // Archive
    arch_title:     "Архив & База знаний",
    arch_subtitle:  "Материалы, добавленные участниками сообщества",
    arch_add:       "Добавить запись",
    arch_empty:     "Архив пуст. Станьте первым!",
    arch_type:      "Тип записи",
    arch_caption:   "Заголовок",
    arch_body:      "Описание / данные",
    arch_tags:      "Теги (через запятую)",
    arch_submit:    "Опубликовать",
    arch_edit:      "Редактировать",
    arch_delete:    "Удалить",
    arch_login_req: "Войдите, чтобы добавлять записи",
    arch_types:     ["Исследование", "Наблюдение", "Рекомендация", "Данные поля", "Вопрос"],

    // Profile
    prof_posts:     "Публикации",
    prof_joined:    "Дата регистрации",
    prof_role:      "Роль",
    prof_edit:      "Редактировать",
    prof_myPosts:   "Мои записи",
    prof_settings:  "Настройки",
    prof_roles:     {admin:"Администратор", expert:"Эксперт", farmer:"Фермер", user:"Пользователь"},

    // SEO guide
    seo_title:      "🔍 Пошаговый SEO Гид",
    seo_subtitle:   "Как вывести сайт в поисковики (Google, Bing, Yandex)",
    step:           "Шаг",

    // Footer
    foot_desc:      "Научный справочник для агрономов и фермеров Центральной Азии. Данные основаны на рецензируемых публикациях.",
    foot_sections:  "Разделы",
    foot_topics:    "Темы",
    foot_author:    "Автор",
    foot_author_name:"yesenow dayanc",
    foot_copy:      "© 2024 ÖŇDE BARYJY ÝYLADYŞHANA · Все права защищены",
    foot_pwa:       "Работает онлайн и офлайн",

    // Common
    search_ph:      "Поиск...",
    loading:        "Загрузка...",
    save:           "Сохранить",
    cancel:         "Отмена",
    close:          "Закрыть",
    delete_confirm: "Удалить эту запись?",
    yes:            "Да",
    no:             "Нет",
    by:             "Автор",
    read_more:      "Подробнее",
    back:           "Назад",
    share:          "Поделиться",
    copied:         "📋 Скопировано!",
    offline_msg:    "📵 Офлайн режим — данные из кэша",
    online_msg:     "✅ Соединение восстановлено",
    nav_search:     "Поиск по сайту",
    calc_tab4:      "Синергизм",
    arch_edit:      "Редактировать запись",
    arch_updated:   "Обновлено",
    arch_views:     "просмотров",
    prof_likes:     "Лайков получено",
    logoutSuccess:  "👋 Вы вышли из системы",
  },

  // ==================== ENGLISH ====================
  en: {
    appName:        "ÖŇDE BARYJY ÝYLADYŞHANA",
    appSub:         "Leading Greenhouse of Central Asia",
    appDesc:        "Scientific reference on pesticides, pollinators & fruit crops",
    tagline:        "Science · Agronomy · Central Asia",

    nav_home:       "Home",
    nav_pesticides: "Pesticides",
    nav_pollinators:"Pollinators",
    nav_fruits:     "Crops",
    nav_risks:      "Risks",
    nav_calc:       "Calculator",
    nav_archive:    "Archive",
    nav_profile:    "Profile",
    nav_seo:        "SEO Guide",
    nav_refs:       "References",

    login:          "Log In",
    register:       "Sign Up",
    logout:         "Log Out",
    profile:        "Profile",
    email:          "Email",
    password:       "Password",
    name:           "Full Name",
    confirmPass:    "Confirm Password",
    noAccount:      "No account?",
    hasAccount:     "Already have an account?",
    forgotPass:     "Forgot password?",
    loginTitle:     "Welcome Back",
    registerTitle:  "Create Account",
    loginSuccess:   "✅ You are logged in!",
    logoutSuccess:  "👋 Logged out",
    registerSuccess:"🎉 Account created!",
    errEmail:       "Enter a valid email",
    errPassLen:     "Password min 6 characters",
    errPassMatch:   "Passwords do not match",
    errNameLen:     "Name min 2 characters",
    errUserExists:  "User already exists",
    errInvalid:     "Invalid email or password",

    hero_badge:     "🌱 Scientific Reference · CA · 2024",
    hero_desc:      "Comprehensive study of pesticide-pollinator interactions in Central Asian agriculture. Data, tables, calculators for agronomists and farmers.",
    hero_btn1:      "Explore Pesticides",
    hero_btn2:      "Calculator",
    stat1_num:      "6+",  stat1_lbl: "Pesticide Classes",
    stat2_num:      "5",   stat2_lbl: "Pollinator Groups",
    stat3_num:      "26%", stat3_lbl: "Yield Increase",
    stat4_num:      "20+", stat4_lbl: "Scientific Sources",

    page_pesticides:"🧪 Pesticide Classes",
    page_pollinators:"🐝 Pollinators",
    page_fruits:    "🍎 Fruit Crops",
    page_risks:     "⚠️ Risks & Toxicity",
    page_calc:      "🧮 Calculator",
    page_archive:   "🗂️ Archive & Knowledge Base",
    page_profile:   "👤 Profile",
    page_seo:       "🔍 SEO Guide",
    page_refs:      "📚 References",

    calc_title:     "Pesticide & Pollinator Calculator",
    calc_tab1:      "Dosage",
    calc_tab2:      "Bee Risk",
    calc_tab3:      "Hives/ha",
    calc_area:      "Treatment area (ha)",
    calc_conc:      "Product concentration (%)",
    calc_rate:      "Water rate (L/ha)",
    calc_substance: "Active ingredient",
    calc_dose:      "A.I. dose (%)",
    calc_bees_exp:  "Expected exposure (ng/bee)",
    calc_crop:      "Crop",
    calc_yield_exp: "Expected yield without pollination (t/ha)",
    calc_btn:       "Calculate",
    calc_result:    "Result:",
    calc_need_prep: "Product needed:",
    calc_need_ai:   "A.I. in spray solution:",
    calc_risk_level:"Risk level:",
    calc_hives:     "Recommended hives:",
    calc_yield_gain:"Yield gain with pollination:",

    arch_title:     "Archive & Knowledge Base",
    arch_subtitle:  "Materials contributed by community members",
    arch_add:       "Add Entry",
    arch_empty:     "Archive is empty. Be the first!",
    arch_type:      "Entry Type",
    arch_caption:   "Title",
    arch_body:      "Description / data",
    arch_tags:      "Tags (comma separated)",
    arch_submit:    "Publish",
    arch_edit:      "Edit",
    arch_delete:    "Delete",
    arch_login_req: "Log in to add entries",
    arch_types:     ["Research", "Observation", "Recommendation", "Field Data", "Question"],

    prof_posts:     "Posts",
    prof_joined:    "Member since",
    prof_role:      "Role",
    prof_edit:      "Edit",
    prof_myPosts:   "My Posts",
    prof_settings:  "Settings",
    prof_roles:     {admin:"Administrator", expert:"Expert", farmer:"Farmer", user:"User"},

    seo_title:      "🔍 Step-by-Step SEO Guide",
    seo_subtitle:   "How to get your site indexed in Google, Bing & Yandex",
    step:           "Step",

    foot_desc:      "Scientific reference for agronomists and farmers of Central Asia. All data based on peer-reviewed publications.",
    foot_sections:  "Sections",
    foot_topics:    "Topics",
    foot_author:    "Author",
    foot_author_name:"yesenow dayanc",
    foot_copy:      "© 2024 ÖŇDE BARYJY ÝYLADYŞHANA · All rights reserved",
    foot_pwa:       "Works online & offline",

    search_ph:      "Search...",
    loading:        "Loading...",
    save:           "Save",
    cancel:         "Cancel",
    close:          "Close",
    delete_confirm: "Delete this entry?",
    yes:            "Yes",
    no:             "No",
    by:             "By",
    read_more:      "Read more",
    back:           "Back",
    share:          "Share",
    copied:         "📋 Copied!",
    offline_msg:    "📵 Offline mode — data from cache",
    online_msg:     "✅ Connection restored",
    nav_search:     "Search site",
    calc_tab4:      "Synergism",
    arch_edit:      "Edit entry",
    arch_updated:   "Updated",
    arch_views:     "views",
    prof_likes:     "Likes received",
    logoutSuccess:  "👋 Logged out",
  },

  // ==================== TURKMEN ====================
  tk: {
    appName:        "ÖŇDE BARYJY ÝYLADYŞHANA",
    appSub:         "Merkezi Aziýanyň öňdebaryjy ýyladyşhanasy",
    appDesc:        "Pestisidler, tozanlaşdyryjylar we miweli ekinler barada ylmy gollanma",
    tagline:        "Ylym · Agronomiya · Merkezi Aziýa",

    nav_home:       "Baş sahypa",
    nav_pesticides: "Pestisidler",
    nav_pollinators:"Tozanlaşdyryjylar",
    nav_fruits:     "Ekinler",
    nav_risks:      "Howplar",
    nav_calc:       "Hasapçy",
    nav_archive:    "Arhiw",
    nav_profile:    "Profil",
    nav_seo:        "SEO Gollanma",
    nav_refs:       "Çeşmeler",

    login:          "Giriş",
    register:       "Hasap açmak",
    logout:         "Çykmak",
    profile:        "Profil",
    email:          "E-poçta",
    password:       "Parol",
    name:           "Ady",
    confirmPass:    "Paroly tassyklaň",
    noAccount:      "Hasabyňyz ýokmy?",
    hasAccount:     "Hasabyňyz barmy?",
    forgotPass:     "Paroly unutdyňyzmy?",
    loginTitle:     "Hoş geldiňiz",
    registerTitle:  "Hasap döretmek",
    loginSuccess:   "✅ Ulgama girdińiz!",
    logoutSuccess:  "👋 Çykdyňyz",
    registerSuccess:"🎉 Hasap döredildi!",
    errEmail:       "Dogry e-poçta girizmeli",
    errPassLen:     "Parol iň az 6 harp bolmaly",
    errPassMatch:   "Parollar gabat gelmeýär",
    errNameLen:     "At iň az 2 harp bolmaly",
    errUserExists:  "Ulanyjy eýýäm bar",
    errInvalid:     "E-poçta ýa parol nädogry",

    hero_badge:     "🌱 Ylmy gollanma · MA · 2024",
    hero_desc:      "Merkezi Aziýanyň oba hojalygynda pestisidleriň tozanlaşdyryjylar bilen täsirini düýpli öwrenmek. Agronomlar we daýhanlar üçin maglumatlar, tablisalar, hasapçylar.",
    hero_btn1:      "Pestisidleri öwren",
    hero_btn2:      "Hasapçy",
    stat1_num:      "6+",  stat1_lbl: "Pestisid synpy",
    stat2_num:      "5",   stat2_lbl: "Tozanlaşdyryjy topary",
    stat3_num:      "26%", stat3_lbl: "Hasyl artmagy",
    stat4_num:      "20+", stat4_lbl: "Ylmy çeşme",

    page_pesticides:"🧪 Pestisid synplary",
    page_pollinators:"🐝 Tozanlaşdyryjylar",
    page_fruits:    "🍎 Miweli ekinler",
    page_risks:     "⚠️ Howplar we zäherlililik",
    page_calc:      "🧮 Hasapçy",
    page_archive:   "🗂️ Arhiw & Bilim binýady",
    page_profile:   "👤 Profil",
    page_seo:       "🔍 SEO Gollanma",
    page_refs:      "📚 Çeşmeler",

    calc_title:     "Pestisid we tozanlaşdyryjy hasapçysy",
    calc_tab1:      "Dozalanma",
    calc_tab2:      "Arylara howp",
    calc_tab3:      "Köwür/ga",
    calc_area:      "Işleýiş meýdany (ga)",
    calc_conc:      "Serişde konsentrasiýasy (%)",
    calc_rate:      "Suw normy (l/ga)",
    calc_substance: "Işjeň madda",
    calc_dose:      "I.m. dozasy (%)",
    calc_bees_exp:  "Garaşylýan täsir (ng/ary)",
    calc_crop:      "Ekin",
    calc_yield_exp: "Tozanlaşdyrylmazdan garaşylýan hasyl (t/ga)",
    calc_btn:       "Hasapla",
    calc_result:    "Netije:",
    calc_need_prep: "Gerek serişde:",
    calc_need_ai:   "Işçi ergindäki i.m.:",
    calc_risk_level:"Howp derejesi:",
    calc_hives:     "Maslahat berilýän köwürler:",
    calc_yield_gain:"Tozanlaşdyrma bilen hasyl artmagy:",

    arch_title:     "Arhiw & Bilim binýady",
    arch_subtitle:  "Jemgyýet agzalary tarapyndan goşulan materiallar",
    arch_add:       "Ýazgy goş",
    arch_empty:     "Arhiw boş. Ilkinji boluň!",
    arch_type:      "Ýazgy görnüşi",
    arch_caption:   "Sözbaşy",
    arch_body:      "Düşündiriş / maglumat",
    arch_tags:      "Bellikler (vergül bilen)",
    arch_submit:    "Çap etmek",
    arch_edit:      "Redaktirlemek",
    arch_delete:    "Pozmak",
    arch_login_req: "Ýazgy goşmak üçin giriş ediň",
    arch_types:     ["Barlag", "Synlama", "Maslahat", "Meýdan maglumaty", "Sorag"],

    prof_posts:     "Çap edilenler",
    prof_joined:    "Hasap açan güni",
    prof_role:      "Rol",
    prof_edit:      "Redaktirlemek",
    prof_myPosts:   "Meniň ýazgylarymy",
    prof_settings:  "Sazlamalar",
    prof_roles:     {admin:"Administrator", expert:"Hünärmen", farmer:"Daýhan", user:"Ulanyjy"},

    seo_title:      "🔍 Ädim-ädim SEO Gollanma",
    seo_subtitle:   "Saýtyňyzy Google, Bing we Yandex-de indekslemek",
    step:           "Ädim",

    foot_desc:      "Merkezi Aziýanyň agronomlary we daýhanlary üçin ylmy gollanma. Ähli maglumatlar ylmy neşirlere esaslanandyr.",
    foot_sections:  "Bölümler",
    foot_topics:    "Mowzuklar",
    foot_author:    "Awtor",
    foot_author_name:"yesenow dayanc",
    foot_copy:      "© 2024 ÖŇDE BARYJY ÝYLADYŞHANA · Ähli hukuklar goralan",
    foot_pwa:       "Onlaýn we oflaýn işleýär",

    search_ph:      "Gözleg...",
    loading:        "Ýüklenýär...",
    save:           "Sakla",
    cancel:         "Ýatyr",
    close:          "Ýap",
    delete_confirm: "Bu ýazgyny pozmalymy?",
    yes:            "Hawa",
    no:             "Ýok",
    by:             "Awtor",
    read_more:      "Giňişleýin",
    back:           "Yza",
    share:          "Paýlaşmak",
    copied:         "📋 Göçürildi!",
    offline_msg:    "📵 Oflaýn düzgün — keşden maglumat",
    online_msg:     "✅ Baglanyşyk dikeldildi",
    nav_search:     "Sahypa gözleg",
    calc_tab4:      "Sinergiziм",
    arch_edit:      "Ýazgyny üýtget",
    arch_updated:   "Täzelendi",
    arch_views:     "görünme",
    prof_likes:     "Alnan begendirmeler",
    logoutSuccess:  "👋 Çykdyňyz",
  }
};

// Текущий язык
let currentLang = localStorage.getItem('obyl_lang') || 'ru';

function t(key) {
  return (TRANSLATIONS[currentLang] && TRANSLATIONS[currentLang][key]) ||
         (TRANSLATIONS['ru'] && TRANSLATIONS['ru'][key]) || key;
}

function setLang(lang) {
  if (!TRANSLATIONS[lang]) return;
  currentLang = lang;
  localStorage.setItem('obyl_lang', lang);
  applyTranslations();
  // Обновляем кнопки
  document.querySelectorAll('.lang-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.lang === lang);
  });
}

function applyTranslations() {
  // Все элементы с data-i18n
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    const val = t(key);
    if (val !== key) {
      if (el.tagName === 'INPUT' && el.placeholder !== undefined) {
        el.placeholder = val;
      } else {
        el.textContent = val;
      }
    }
  });
  // data-i18n-placeholder
  document.querySelectorAll('[data-i18n-ph]').forEach(el => {
    el.placeholder = t(el.dataset.i18nPh);
  });
  // Обновляем специфические элементы
  const appNameEls = document.querySelectorAll('.brand-main');
  appNameEls.forEach(el => el.textContent = t('appName'));
  const appSubEls = document.querySelectorAll('.brand-sub');
  appSubEls.forEach(el => el.textContent = t('appSub'));
  // Обновляем заголовок страницы
  document.title = t('appName') + ' — ' + t('appDesc');
}
