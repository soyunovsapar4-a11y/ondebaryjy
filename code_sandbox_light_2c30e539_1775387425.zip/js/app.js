// =====================================================
// ÖŇDE BARYJY ÝYLADYŞHANA — App Logic v2.0
// Auth + Archive + Calculator + Charts + SEO Guide
// Author: yesenow dayanc
// =====================================================

// ============================================================
// ===== SECTION 1: AUTH SYSTEM (localStorage) ================
// ============================================================

const AUTH = {
  STORAGE_KEY: 'obyl_users',
  SESSION_KEY: 'obyl_session',

  getUsers() {
    try { return JSON.parse(localStorage.getItem(this.STORAGE_KEY) || '[]'); }
    catch { return []; }
  },
  saveUsers(users) {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(users));
  },
  getSession() {
    try { return JSON.parse(localStorage.getItem(this.SESSION_KEY) || 'null'); }
    catch { return null; }
  },
  setSession(user) {
    localStorage.setItem(this.SESSION_KEY, JSON.stringify(user));
  },
  clearSession() {
    localStorage.removeItem(this.SESSION_KEY);
  },
  isLoggedIn() { return !!this.getSession(); },
  currentUser() { return this.getSession(); },

  register(name, email, password) {
    const users = this.getUsers();
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) return { ok: false, err: 'errUserExists' };
    const user = {
      id: Date.now().toString(36),
      name, email: email.toLowerCase(), password,
      role: users.length === 0 ? 'admin' : 'user',
      joined: new Date().toISOString(),
      posts: 0,
      avatar: name.charAt(0).toUpperCase()
    };
    users.push(user);
    this.saveUsers(users);
    const session = { ...user }; delete session.password;
    this.setSession(session);
    return { ok: true, user: session };
  },

  login(email, password) {
    const users = this.getUsers();
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    if (!user) return { ok: false, err: 'errInvalid' };
    const session = { ...user }; delete session.password;
    this.setSession(session);
    return { ok: true, user: session };
  },

  logout() {
    this.clearSession();
    updateNavAuth();
    showPage('home');
    showToast(t('logoutSuccess'));
  },

  updateUserPosts() {
    const session = this.getSession();
    if (!session) return;
    const posts = ARCHIVE.getPosts().filter(p => p.authorId === session.id).length;
    session.posts = posts;
    this.setSession(session);
    // Update in users list
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === session.id);
    if (idx !== -1) { users[idx].posts = posts; this.saveUsers(users); }
  }
};

// ============================================================
// ===== SECTION 2: ARCHIVE / KNOWLEDGE BASE ==================
// ============================================================

const ARCHIVE = {
  KEY: 'obyl_archive',

  getPosts() {
    try { return JSON.parse(localStorage.getItem(this.KEY) || '[]'); }
    catch { return []; }
  },
  savePosts(posts) {
    localStorage.setItem(this.KEY, JSON.stringify(posts));
  },
  addPost(post) {
    const posts = this.getPosts();
    const entry = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2,5),
      ...post,
      createdAt: new Date().toISOString(),
      likes: 0,
      likedBy: []
    };
    posts.unshift(entry);
    this.savePosts(posts);
    AUTH.updateUserPosts();
    return entry;
  },
  deletePost(id) {
    const user = AUTH.currentUser();
    if (!user) return false;
    let posts = this.getPosts();
    const post = posts.find(p => p.id === id);
    if (!post) return false;
    if (post.authorId !== user.id && user.role !== 'admin') return false;
    posts = posts.filter(p => p.id !== id);
    this.savePosts(posts);
    AUTH.updateUserPosts();
    return true;
  },
  likePost(id) {
    const user = AUTH.currentUser();
    if (!user) return false;
    const posts = this.getPosts();
    const post = posts.find(p => p.id === id);
    if (!post) return false;
    if (!post.likedBy) post.likedBy = [];
    const idx = post.likedBy.indexOf(user.id);
    if (idx === -1) { post.likedBy.push(user.id); post.likes = (post.likes||0)+1; }
    else { post.likedBy.splice(idx,1); post.likes = Math.max(0,(post.likes||0)-1); }
    this.savePosts(posts);
    return post.likes;
  },
  seedDefaults() {
    if (this.getPosts().length > 0) return;
    const defaults = [
      { title:'Имидаклоприд в нектаре яблони — полевые данные 2023', type:'Данные поля', body:'Обнаружены следы имидаклоприда (4.2 мкг/кг) в нектаре яблони через 21 день после почвенного внесения. Рекомендуется минимальный разрыв 28 дней перед цветением.', tags:['имидаклоприд','яблоня','нектар'], authorId:'sys', authorName:'ÖŇDE BARYJY', authorAvatar:'Ö', createdAt:'2024-01-15T10:00:00Z', likes:12, likedBy:[] },
      { title:'Bombus terrestris в теплицах Узбекистана', type:'Наблюдение', body:'Испытание Bombus terrestris в теплицах томата (Ташкентская обл.). Завязываемость плодов возросла с 62% до 89% при плотности 1 гнездо/500 м². Температурный оптимум 18–22°C.', tags:['шмели','теплица','томат','Узбекистан'], authorId:'sys', authorName:'ÖŇDE BARYJY', authorAvatar:'Ö', createdAt:'2024-02-20T09:00:00Z', likes:8, likedBy:[] },
      { title:'Безопасные акарициды для яблони в период цветения', type:'Рекомендация', body:'По результатам тестов в Алма-Атинской области: клофентезин и гекситиазокс показали минимальное влияние на Apis mellifera даже при нанесении в период цветения. Абамектин — абсолютный запрет.', tags:['акарициды','яблоня','безопасность','ЦА'], authorId:'sys', authorName:'ÖŇDE BARYJY', authorAvatar:'Ö', createdAt:'2024-03-05T11:00:00Z', likes:15, likedBy:[] },
    ];
    this.savePosts(defaults);
  }
};

// ============================================================
// ===== SECTION 3: NAVIGATION & PAGES ========================
// ============================================================

window.currentPage = 'home';
window._pageInited = {};

function showPage(pageName) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const target = document.getElementById('page-' + pageName);
  if (target) { target.classList.add('active'); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  document.querySelectorAll('.nav-links a').forEach(a => {
    a.classList.toggle('active', a.dataset.page === pageName);
  });
  document.querySelector('.nav-center')?.classList.remove('open');
  window.currentPage = pageName;

  if (!window._pageInited[pageName]) {
    window._pageInited[pageName] = true;
    const initMap = {
      home:            initHomeCharts,
      pollinators:     initPolChart,
      fruits:          initFruitChart,
      risks:           initRisksChart,
      archive:         renderArchive,
      profile:         renderProfile,
      references:      renderRefs,
      seo:             () => {},
    };
    if (initMap[pageName]) setTimeout(initMap[pageName], 200);
  } else if (pageName === 'archive') {
    renderArchive();
  } else if (pageName === 'profile') {
    renderProfile();
  }
}

function toggleMenu() {
  document.querySelector('.nav-center')?.classList.toggle('open');
}

// ============================================================
// ===== SECTION 4: AUTH UI ====================================
// ============================================================

function updateNavAuth() {
  const user = AUTH.currentUser();
  const loginArea = document.getElementById('navAuthArea');
  if (!loginArea) return;
  if (user) {
    loginArea.innerHTML = `
      <div class="user-nav" onclick="toggleUserMenu()">
        <div class="user-avatar-sm">${user.avatar||user.name.charAt(0).toUpperCase()}</div>
        <span class="user-name-sm" style="max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${user.name}</span>
        <i class="fas fa-chevron-down" style="font-size:.7rem;color:var(--c-text3)"></i>
      </div>
      <div id="userDropdown" style="display:none;position:absolute;top:56px;right:1rem;background:var(--c-card);border:1px solid var(--c-border2);border-radius:var(--r-md);min-width:180px;box-shadow:var(--shadow-md);z-index:1001;overflow:hidden">
        <a href="#" onclick="showPage('profile');toggleUserMenu()" style="display:flex;align-items:center;gap:.6rem;padding:.75rem 1rem;color:var(--c-text2);text-decoration:none;font-size:.88rem;transition:var(--t)" onmouseover="this.style.background='rgba(76,175,80,.1)'" onmouseout="this.style.background=''"><i class="fas fa-user"></i> <span data-i18n="profile"></span></a>
        <a href="#" onclick="showPage('archive');toggleUserMenu()" style="display:flex;align-items:center;gap:.6rem;padding:.75rem 1rem;color:var(--c-text2);text-decoration:none;font-size:.88rem;transition:var(--t)" onmouseover="this.style.background='rgba(76,175,80,.1)'" onmouseout="this.style.background=''"><i class="fas fa-archive"></i> <span data-i18n="nav_archive"></span></a>
        <div style="border-top:1px solid var(--c-border);margin:.2rem 0"></div>
        <a href="#" onclick="AUTH.logout();toggleUserMenu()" style="display:flex;align-items:center;gap:.6rem;padding:.75rem 1rem;color:#ef9a9a;text-decoration:none;font-size:.88rem;transition:var(--t)" onmouseover="this.style.background='rgba(244,67,54,.1)'" onmouseout="this.style.background=''"><i class="fas fa-sign-out-alt"></i> <span data-i18n="logout"></span></a>
      </div>`;
  } else {
    loginArea.innerHTML = `
      <button class="btn-auth btn-login" onclick="openModal('loginModal')" data-i18n="login">${t('login')}</button>
      <button class="btn-auth btn-register" onclick="openModal('registerModal')" data-i18n="register">${t('register')}</button>`;
  }
  applyTranslations();
}

function toggleUserMenu() {
  const dd = document.getElementById('userDropdown');
  if (dd) dd.style.display = dd.style.display === 'none' ? 'block' : 'none';
}

document.addEventListener('click', (e) => {
  const dd = document.getElementById('userDropdown');
  if (dd && !dd.closest('.user-nav')?.contains(e.target) && !dd.contains(e.target)) {
    dd.style.display = 'none';
  }
});

// ============================================================
// ===== SECTION 5: MODALS =====================================
// ============================================================

function openModal(id) {
  document.getElementById(id)?.classList.add('open');
}
function closeModal(id) {
  document.getElementById(id)?.classList.remove('open');
}

// Close on overlay click
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});

// LOGIN FORM
function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value.trim();
  const pass  = document.getElementById('loginPass').value;
  const errEl = document.getElementById('loginErr');

  if (!email.includes('@')) { errEl.textContent = t('errEmail'); return; }
  if (pass.length < 6)      { errEl.textContent = t('errPassLen'); return; }

  const result = AUTH.login(email, pass);
  if (!result.ok) { errEl.textContent = t(result.err); return; }
  errEl.textContent = '';
  closeModal('loginModal');
  updateNavAuth();
  showToast(t('loginSuccess'));
  showPage('profile');
}

// REGISTER FORM
function handleRegister(e) {
  e.preventDefault();
  const name  = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const pass  = document.getElementById('regPass').value;
  const pass2 = document.getElementById('regPass2').value;
  const errEl = document.getElementById('regErr');

  if (name.length < 2)          { errEl.textContent = t('errNameLen');  return; }
  if (!email.includes('@'))     { errEl.textContent = t('errEmail');     return; }
  if (pass.length < 6)          { errEl.textContent = t('errPassLen');   return; }
  if (pass !== pass2)           { errEl.textContent = t('errPassMatch'); return; }

  const result = AUTH.register(name, email, pass);
  if (!result.ok) { errEl.textContent = t(result.err); return; }
  errEl.textContent = '';
  closeModal('registerModal');
  updateNavAuth();
  showToast(t('registerSuccess'));
  showPage('profile');
}

// ============================================================
// ===== SECTION 6: ARCHIVE PAGE ===============================
// ============================================================

function renderArchive() {
  const container = document.getElementById('archiveFeed');
  if (!container) return;
  const user  = AUTH.currentUser();
  const posts = ARCHIVE.getPosts();
  const q     = (document.getElementById('archSearch')?.value || '').toLowerCase();
  const fType = document.getElementById('archFilter')?.value || '';

  const filtered = posts.filter(p => {
    const text = `${p.title} ${p.body} ${p.tags?.join(' ')||''}`.toLowerCase();
    return (!q || text.includes(q)) && (!fType || p.type === fType);
  });

  // Update count
  const countEl = document.getElementById('archCount');
  if (countEl) countEl.textContent = filtered.length;

  if (filtered.length === 0) {
    container.innerHTML = `<div style="text-align:center;padding:4rem;color:var(--c-text3)"><div style="font-size:3rem;margin-bottom:1rem">🗂️</div><p>${t('arch_empty')}</p></div>`;
    return;
  }

  container.innerHTML = filtered.map(p => {
    const isOwner = user && (user.id === p.authorId || user.role === 'admin');
    const liked   = user && p.likedBy?.includes(user.id);
    const date    = new Date(p.createdAt).toLocaleDateString(currentLang === 'en' ? 'en-US' : (currentLang === 'tk' ? 'tk-TM' : 'ru-RU'), {day:'numeric',month:'short',year:'numeric'});
    const typeColors = { 'Исследование':'tag-blue','Research':'tag-blue','Barlag':'tag-blue','Наблюдение':'tag-green','Observation':'tag-green','Synlama':'tag-green','Рекомендация':'tag-gold','Recommendation':'tag-gold','Maslahat':'tag-gold','Данные поля':'tag-purple','Field Data':'tag-purple','Meýdan maglumaty':'tag-purple','Вопрос':'tag-orange','Question':'tag-orange','Sorag':'tag-orange' };
    const tagCls = typeColors[p.type] || 'tag-blue';
    return `<div class="feed-item" id="post-${p.id}">
      <div class="feed-avatar">${p.authorAvatar||'?'}</div>
      <div style="flex:1;min-width:0">
        <div class="feed-meta">
          <span style="font-weight:700;color:var(--c-text2)">${p.authorName}</span>
          · ${date} · <span class="tag ${tagCls}" style="font-size:.7rem">${p.type}</span>
        </div>
        <h4 style="font-size:.95rem;font-weight:700;margin-bottom:.4rem;color:var(--c-text)">${p.title}</h4>
        <p class="feed-text">${p.body}</p>
        ${p.tags?.length ? `<div style="margin-top:.5rem">${p.tags.map(tg=>`<span class="tag tag-green" style="font-size:.7rem">${tg}</span>`).join('')}</div>` : ''}
        <div class="feed-actions">
          <button onclick="handleLike('${p.id}')" style="background:${liked?'rgba(244,67,54,.15)':'none'};border:1px solid var(--c-border);border-radius:50px;padding:.25rem .7rem;color:${liked?'#ef9a9a':'var(--c-text3)'};font-size:.8rem;cursor:pointer;transition:var(--t);display:flex;align-items:center;gap:.3rem" onmouseover="this.style.borderColor='var(--c-red)'" onmouseout="this.style.borderColor='var(--c-border)'">
            <i class="fas fa-heart"></i> <span id="likes-${p.id}">${p.likes||0}</span>
          </button>
          <span style="display:flex;align-items:center;gap:.3rem;font-size:.78rem;color:var(--c-text3)"><i class="fas fa-eye"></i> ${p.views||0}</span>
          <button onclick="sharePost('${p.id}')" style="background:none;border:1px solid var(--c-border);border-radius:50px;padding:.25rem .7rem;color:var(--c-text3);font-size:.8rem;cursor:pointer;transition:var(--t)" onmouseover="this.style.borderColor='var(--c-primary-l)'" onmouseout="this.style.borderColor='var(--c-border)'">
            <i class="fas fa-share-alt"></i>
          </button>
          ${isOwner ? `
          <button onclick="openEditPost('${p.id}')" style="background:none;border:1px solid var(--c-border);border-radius:50px;padding:.25rem .7rem;color:var(--c-text3);font-size:.8rem;cursor:pointer;transition:var(--t)" onmouseover="this.style.borderColor='var(--c-gold)';this.style.color='var(--c-gold-l)'" onmouseout="this.style.borderColor='var(--c-border)';this.style.color='var(--c-text3)'">
            <i class="fas fa-edit"></i>
          </button>
          <button onclick="deletePost('${p.id}')" style="background:none;border:1px solid var(--c-border);border-radius:50px;padding:.25rem .7rem;color:var(--c-text3);font-size:.8rem;cursor:pointer;transition:var(--t);margin-left:auto" onmouseover="this.style.borderColor='var(--c-red)';this.style.color='#ef9a9a'" onmouseout="this.style.borderColor='var(--c-border)';this.style.color='var(--c-text3)'">
            <i class="fas fa-trash"></i>
          </button>` : ''}
        </div>
      </div>
    </div>`;
  }).join('');
}

function handleLike(postId) {
  if (!AUTH.isLoggedIn()) { openModal('loginModal'); return; }
  const newLikes = ARCHIVE.likePost(postId);
  const el = document.getElementById(`likes-${postId}`);
  if (el) el.textContent = newLikes;
  renderArchive();
}

function deletePost(id) {
  if (!confirm(t('delete_confirm'))) return;
  if (ARCHIVE.deletePost(id)) {
    renderArchive();
    showToast('🗑️ Удалено');
  }
}

function sharePost(id) {
  const url = window.location.href.split('?')[0] + `?page=archive&post=${id}`;
  navigator.clipboard.writeText(url).then(() => showToast(t('copied')));
}

function submitArchivePost(e) {
  e.preventDefault();
  const user = AUTH.currentUser();
  if (!user) { openModal('loginModal'); return; }
  const title = document.getElementById('newPostTitle')?.value.trim();
  const body  = document.getElementById('newPostBody')?.value.trim();
  const type  = document.getElementById('newPostType')?.value;
  const tags  = document.getElementById('newPostTags')?.value.split(',').map(s=>s.trim()).filter(Boolean);
  if (!title || !body) return;
  ARCHIVE.addPost({ title, body, type, tags, authorId: user.id, authorName: user.name, authorAvatar: user.avatar || user.name.charAt(0).toUpperCase() });
  e.target.reset();
  closeModal('addPostModal');
  renderArchive();
  showToast('✅ ' + t('arch_submit'));
  window._pageInited['profile'] = false;
}

// ============================================================
// ===== SECTION 7: PROFILE PAGE ===============================
// ============================================================

function renderProfile() {
  const container = document.getElementById('profileContent');
  if (!container) return;
  const user = AUTH.currentUser();
  if (!user) {
    container.innerHTML = `<div style="text-align:center;padding:4rem">
      <div style="font-size:3rem;margin-bottom:1rem">🔐</div>
      <p style="color:var(--c-text2);margin-bottom:1.5rem">${t('arch_login_req')}</p>
      <button class="btn btn-primary" onclick="openModal('loginModal')">${t('login')}</button>
      <button class="btn btn-outline" onclick="openModal('registerModal')" style="margin-left:.8rem">${t('register')}</button>
    </div>`;
    return;
  }
  const myPosts = ARCHIVE.getPosts().filter(p => p.authorId === user.id);
  const roleLabel = t('prof_roles')[user.role] || user.role;
  const joined = new Date(user.joined).toLocaleDateString(currentLang === 'en' ? 'en-US' : 'ru-RU', {day:'numeric',month:'long',year:'numeric'});

  container.innerHTML = `
    <div class="profile-header">
      <div class="profile-avatar">${user.avatar || user.name.charAt(0).toUpperCase()}</div>
      <div class="profile-info" style="flex:1">
        <h2>${user.name}</h2>
        <div class="role-badge">${roleLabel}</div>
        <p>${user.email}</p>
        <div class="profile-stats">
          <div class="pstat"><div class="num">${myPosts.length}</div><div class="lbl">${t('prof_posts')}</div></div>
          <div class="pstat"><div class="num">${myPosts.reduce((a,p)=>a+(p.likes||0),0)}</div><div class="lbl">Лайков</div></div>
          <div class="pstat"><div class="num">${joined}</div><div class="lbl">${t('prof_joined')}</div></div>
        </div>
      </div>
    </div>

    <div class="tabs">
      <button class="tab-btn active" onclick="openTab(this,'ptab-posts')"><i class="fas fa-file-alt"></i> ${t('prof_myPosts')} (${myPosts.length})</button>
      <button class="tab-btn" onclick="openTab(this,'ptab-settings')"><i class="fas fa-cog"></i> ${t('prof_settings')}</button>
    </div>

    <div id="ptab-posts" class="tab-pane active">
      ${myPosts.length === 0
        ? `<div style="text-align:center;padding:3rem;color:var(--c-text3)"><p>Вы ещё не добавили ни одной записи.</p><button class="btn btn-primary" style="margin-top:1rem" onclick="showPage('archive');setTimeout(()=>openModal('addPostModal'),300)">Добавить первую запись</button></div>`
        : myPosts.map(p=>`<div class="feed-item"><div class="feed-avatar">${p.authorAvatar}</div><div style="flex:1"><div class="feed-meta">${new Date(p.createdAt).toLocaleDateString('ru-RU')} · <span class="tag tag-gold" style="font-size:.7rem">${p.type}</span></div><h4 style="font-size:.93rem;font-weight:700;color:var(--c-text)">${p.title}</h4><p class="feed-text" style="font-size:.85rem">${p.body.slice(0,140)}${p.body.length>140?'...':''}</p><div class="feed-actions"><span style="font-size:.8rem;color:var(--c-text3)"><i class="fas fa-heart" style="color:#ef9a9a"></i> ${p.likes||0}</span><button onclick="deletePost('${p.id}');renderProfile()" style="background:none;border:1px solid var(--c-border);border-radius:50px;padding:.2rem .6rem;color:var(--c-text3);font-size:.78rem;cursor:pointer;margin-left:auto"><i class="fas fa-trash"></i></button></div></div></div>`).join('')
      }
    </div>

    <div id="ptab-settings" class="tab-pane">
      <div class="card" style="max-width:480px">
        <h3 style="margin-bottom:1.2rem">${t('prof_settings')}</h3>
        <form onsubmit="saveSettings(event)">
          <div class="form-group"><label class="form-label">Имя</label><input class="form-input" id="settName" value="${user.name}"></div>
          <div class="form-group"><label class="form-label">Email</label><input class="form-input" id="settEmail" value="${user.email}"></div>
          <div class="form-group"><label class="form-label">Новый пароль (оставьте пустым)</label><input class="form-input" id="settPass" type="password" placeholder="••••••"></div>
          <button class="btn btn-primary" type="submit" style="width:100%"><i class="fas fa-save"></i> ${t('save')}</button>
        </form>
      </div>
    </div>`;
}

function saveSettings(e) {
  e.preventDefault();
  const user = AUTH.currentUser();
  if (!user) return;
  const name  = document.getElementById('settName').value.trim();
  const email = document.getElementById('settEmail').value.trim();
  const pass  = document.getElementById('settPass').value;
  const users = AUTH.getUsers();
  const idx   = users.findIndex(u => u.id === user.id);
  if (idx === -1) return;
  if (name.length >= 2)  { users[idx].name  = name;  user.name  = name; }
  if (email.includes('@')){ users[idx].email = email; user.email = email; }
  if (pass.length >= 6)  { users[idx].password = pass; }
  users[idx].avatar = name.charAt(0).toUpperCase();
  user.avatar = users[idx].avatar;
  AUTH.saveUsers(users);
  AUTH.setSession(user);
  updateNavAuth();
  showToast(t('save') + ' ✅');
  window._pageInited['profile'] = false;
  renderProfile();
}

// ============================================================
// ===== SECTION 8: CALCULATOR =================================
// ============================================================

const CALC = {
  ld50Data: {
    'Дельтаметрин / Deltamethrin':  { ld50: 0.002,  class: 'пиретроид',     risk: 'КРИТИЧЕСКИЙ' },
    'Λ-цигалотрин / Lambda-cyhal.': { ld50: 0.038,  class: 'пиретроид',     risk: 'КРИТИЧЕСКИЙ' },
    'Имидаклоприд / Imidacloprid':  { ld50: 0.0037, class: 'неоникотиноид', risk: 'КРИТИЧЕСКИЙ' },
    'Клотианидин / Clothianidin':   { ld50: 0.0038, class: 'неоникотиноид', risk: 'КРИТИЧЕСКИЙ' },
    'Тиаметоксам / Thiamethoxam':   { ld50: 0.0049, class: 'неоникотиноид', risk: 'КРИТИЧЕСКИЙ' },
    'Ацетамиприд / Acetamiprid':    { ld50: 0.0081, class: 'неоникотиноид', risk: 'ВЫСОКИЙ' },
    'Хлорпирифос / Chlorpyrifos':   { ld50: 0.059,  class: 'ФОС',           risk: 'КРИТИЧЕСКИЙ' },
    'Малатион / Malathion':         { ld50: 0.18,   class: 'ФОС',           risk: 'КРИТИЧЕСКИЙ' },
    'Карбарил / Carbaryl':          { ld50: 0.18,   class: 'карбамат',      risk: 'КРИТИЧЕСКИЙ' },
    'Тебуконазол / Tebuconazole':   { ld50: 25,     class: 'фунгицид',      risk: 'НИЗКИЙ' },
    'Глифосат / Glyphosate':        { ld50: 98,     class: 'гербицид',      risk: 'НИЗКИЙ' },
    'Клофентезин / Clofentezine':   { ld50: 200,    class: 'акарицид',      risk: 'БЕЗОПАСНЫЙ' },
  },

  hivesData: {
    'Яблоня / Apple':    { hives: 3, gain: 26 },
    'Груша / Pear':      { hives: 3, gain: 20 },
    'Черешня / Cherry':  { hives: 4, gain: 35 },
    'Вишня / Sour ch.':  { hives: 2.5, gain: 28 },
    'Абрикос / Apricot': { hives: 2.5, gain: 18 },
    'Персик / Peach':    { hives: 1.5, gain: 12 },
    'Слива / Plum':      { hives: 3, gain: 22 },
    'Нектарин':          { hives: 1.5, gain: 12 },
  },

  calcDosage() {
    const area = parseFloat(document.getElementById('c_area')?.value) || 0;
    const conc = parseFloat(document.getElementById('c_conc')?.value) || 0;
    const rate = parseFloat(document.getElementById('c_rate')?.value) || 0;
    if (!area || !conc || !rate) return;
    const totalWater = area * rate;
    const aiPerHa    = rate * (conc / 100);
    const totalAI    = area * aiPerHa;
    document.getElementById('cr_water').textContent  = totalWater.toFixed(0) + ' л';
    document.getElementById('cr_prep').textContent   = (area * rate / (conc/100) / 100).toFixed(2) + ' кг / л';
    document.getElementById('cr_ai').textContent     = totalAI.toFixed(3) + ' кг';
    document.getElementById('calcDosResult').style.display = 'block';
  },

  calcRisk() {
    const subst = document.getElementById('c_substance')?.value;
    const exp   = parseFloat(document.getElementById('c_bees_exp')?.value) || 0;
    if (!subst || !exp) return;
    const data = this.ld50Data[subst];
    if (!data) return;
    const ratio = exp / data.ld50;
    const pct   = Math.min(100, ratio * 100).toFixed(1);
    const isLethal = ratio >= 1;
    const riskColors = { 'КРИТИЧЕСКИЙ':'var(--c-red)','ВЫСОКИЙ':'var(--c-orange)','НИЗКИЙ':'var(--c-primary-l)','БЕЗОПАСНЫЙ':'var(--c-accent)' };
    document.getElementById('cr_ld50').textContent  = data.ld50 + ' мкг/пчела';
    document.getElementById('cr_class').textContent = data.class;
    document.getElementById('cr_ratio').textContent = ratio.toFixed(2) + 'x';
    document.getElementById('cr_risk').textContent  = data.risk;
    document.getElementById('cr_risk').style.color  = riskColors[data.risk] || 'white';
    const bar = document.getElementById('cr_bar');
    if (bar) { bar.style.width = Math.min(100,pct)+'%'; bar.style.background = isLethal ? 'var(--c-red)' : riskColors[data.risk]; }
    document.getElementById('calcRiskResult').style.display = 'block';
  },

  calcHives() {
    const crop  = document.getElementById('c_crop')?.value;
    const area  = parseFloat(document.getElementById('c_hive_area')?.value) || 0;
    const ybase = parseFloat(document.getElementById('c_yield')?.value) || 0;
    if (!crop || !area) return;
    const data  = this.hivesData[crop];
    if (!data) return;
    const hives     = Math.ceil(area * data.hives);
    const yieldGain = ybase > 0 ? (ybase * data.gain / 100).toFixed(2) : '—';
    const yieldTot  = ybase > 0 ? (ybase + ybase * data.gain / 100).toFixed(2) : '—';
    document.getElementById('cr_hives_total').textContent  = hives + ' ' + t('calc_hives').split(':')[0];
    document.getElementById('cr_hive_need').textContent    = data.hives + ' / га';
    document.getElementById('cr_gain_pct').textContent     = '+' + data.gain + '%';
    document.getElementById('cr_gain_abs').textContent     = yieldGain !== '—' ? `+${yieldGain} т/га → итого ${yieldTot} т/га` : '—';
    document.getElementById('calcHiveResult').style.display = 'block';
  }
};

// ============================================================
// ===== SECTION 2b: ARCHIVE — EDIT & EXTRA METHODS ===========
// ============================================================

// editPost: обновление существующей записи
ARCHIVE.editPost = function(id, patch) {
  const user = AUTH.currentUser();
  if (!user) return false;
  const posts = this.getPosts();
  const idx = posts.findIndex(p => p.id === id);
  if (idx === -1) return false;
  const post = posts[idx];
  if (post.authorId !== user.id && user.role !== 'admin') return false;
  posts[idx] = { ...post, ...patch, updatedAt: new Date().toISOString() };
  this.savePosts(posts);
  return true;
};

// incrementView: счётчик просмотров
ARCHIVE.incrementView = function(id) {
  const posts = this.getPosts();
  const post = posts.find(p => p.id === id);
  if (!post) return;
  post.views = (post.views || 0) + 1;
  this.savePosts(posts);
};

// ============================================================
// ===== GLOBAL SEARCH =========================================
// ============================================================

const SEARCH_INDEX = [
  { page:'pesticides', title:'Неоникотиноиды', body:'Имидаклоприд, Клотианидин, Тиаметоксам, Ацетамиприд, блокируют nAChR, системные' },
  { page:'pesticides', title:'Пиретроиды', body:'Дельтаметрин, Циперметрин, натриевые каналы, контактная токсичность' },
  { page:'pesticides', title:'ФОС / Карбаматы', body:'Хлорпирифос, Малатион, ингибиторы АХЭ' },
  { page:'pesticides', title:'Фунгициды & Гербициды', body:'Глифосат, Азоксистробин, синергизм CYP450' },
  { page:'pollinators', title:'Apis mellifera', body:'Медоносная пчела, 10-12°C, 2-8 семей/га' },
  { page:'pollinators', title:'Bombus spp.', body:'Шмели, 5°C, холодостойкий, баззинг, теплицы' },
  { page:'pollinators', title:'Osmia spp.', body:'Пчёлы-каменщицы, ×120 эффективность яблоня' },
  { page:'fruits', title:'Яблоня', body:'+11-26%, 2-4 улья/га, Apis Osmia' },
  { page:'fruits', title:'Черешня', body:'+35%, самобесплодна, 3-5 улья/га' },
  { page:'fruits', title:'Абрикос', body:'+18%, Bombus, ранее цветение' },
  { page:'risks', title:'Риски пестицидов', body:'CCD, нектар 15 мкг/кг, пыльца 100 мкг/кг, гуттация' },
  { page:'calculator', title:'Калькулятор дозировки', body:'Расчёт дозы препарата, площадь, концентрация' },
  { page:'calculator', title:'Оценка риска для пчёл', body:'LD50, соотношение воздействие/LD50' },
  { page:'archive', title:'Архив знаний', body:'Исследования, наблюдения, рекомендации сообщества' },
  { page:'seo', title:'SEO Руководство', body:'Google Search Console, Yandex, Bing, sitemap, robots' },
  { page:'references', title:'Научные источники', body:'Whitehorn 2012, Henry 2012, EFSA 2023, FAO 2020' },
];

function runGlobalSearch(q) {
  const box = document.getElementById('globalSearchResults');
  if (!box) return;
  if (!q || q.length < 2) { box.innerHTML = `<p style="text-align:center;color:var(--c-text3);padding:2rem">Введите запрос...</p>`; return; }
  const ql = q.toLowerCase();
  // Search in index
  const staticResults = SEARCH_INDEX.filter(it => `${it.title} ${it.body}`.toLowerCase().includes(ql));
  // Search in archive
  const archResults = ARCHIVE.getPosts().filter(p => `${p.title} ${p.body} ${(p.tags||[]).join(' ')}`.toLowerCase().includes(ql));
  if (staticResults.length === 0 && archResults.length === 0) {
    box.innerHTML = `<p style="text-align:center;color:var(--c-text3);padding:2rem">😔 Ничего не найдено</p>`;
    return;
  }
  let html = '';
  if (staticResults.length) {
    html += `<div style="font-size:.75rem;color:var(--c-text3);text-transform:uppercase;margin-bottom:.5rem;letter-spacing:.06em">Разделы сайта</div>`;
    html += staticResults.map(it=>`<div onclick="closeModal('globalSearchModal');showPage('${it.page}')" style="display:flex;align-items:center;gap:.8rem;padding:.7rem .9rem;border-radius:var(--r-sm);cursor:pointer;transition:var(--t);border:1px solid transparent" onmouseover="this.style.background='rgba(76,175,80,.08)';this.style.borderColor='var(--c-border)'" onmouseout="this.style.background='';this.style.borderColor='transparent'">
      <div style="width:34px;height:34px;border-radius:8px;background:rgba(76,175,80,.15);display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0">📄</div>
      <div><div style="font-weight:700;color:var(--c-text);font-size:.9rem">${it.title}</div><div style="font-size:.78rem;color:var(--c-text3)">${it.body.slice(0,80)}...</div></div>
    </div>`).join('');
  }
  if (archResults.length) {
    html += `<div style="font-size:.75rem;color:var(--c-text3);text-transform:uppercase;margin:.8rem 0 .5rem;letter-spacing:.06em">Архив сообщества</div>`;
    html += archResults.slice(0,5).map(p=>`<div onclick="closeModal('globalSearchModal');showPage('archive')" style="display:flex;align-items:center;gap:.8rem;padding:.7rem .9rem;border-radius:var(--r-sm);cursor:pointer;transition:var(--t);border:1px solid transparent" onmouseover="this.style.background='rgba(76,175,80,.08)';this.style.borderColor='var(--c-border)'" onmouseout="this.style.background='';this.style.borderColor='transparent'">
      <div style="width:34px;height:34px;border-radius:8px;background:rgba(249,168,37,.15);display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0">🗂️</div>
      <div><div style="font-weight:700;color:var(--c-text);font-size:.9rem">${p.title}</div><div style="font-size:.78rem;color:var(--c-text3)">${p.body.slice(0,80)}...</div></div>
    </div>`).join('');
  }
  box.innerHTML = html;
}

// ============================================================
// ===== EDIT POST MODAL =======================================
// ============================================================

function openEditPost(postId) {
  const posts = ARCHIVE.getPosts();
  const post = posts.find(p => p.id === postId);
  if (!post) return;
  document.getElementById('editPostId').value = post.id;
  document.getElementById('editPostTitle').value = post.title;
  document.getElementById('editPostBody').value = post.body;
  document.getElementById('editPostTags').value = (post.tags||[]).join(', ');
  // set type
  const sel = document.getElementById('editPostType');
  if (sel) for (let opt of sel.options) { if (opt.value === post.type) { opt.selected = true; break; } }
  openModal('editPostModal');
}

function submitEditPost(e) {
  e.preventDefault();
  const id    = document.getElementById('editPostId').value;
  const title = document.getElementById('editPostTitle').value.trim();
  const body  = document.getElementById('editPostBody').value.trim();
  const type  = document.getElementById('editPostType').value;
  const tags  = document.getElementById('editPostTags').value.split(',').map(s=>s.trim()).filter(Boolean);
  if (!title || !body) return;
  if (ARCHIVE.editPost(id, { title, body, type, tags })) {
    closeModal('editPostModal');
    renderArchive();
    showToast('✅ Запись обновлена');
    window._pageInited['profile'] = false;
  }
}

// ============================================================
// ===== SYNERGY CALCULATOR (New Module) =======================
// ============================================================

const SYNERGY_DATA = [
  { f:'Проциназол', i:'Имидаклоприд', factor:35, note:'LC50 снижается в 35 раз' },
  { f:'Хлороталонил', i:'Ацетамиприд', factor:12, note:'Сублетальный синергизм' },
  { f:'Тебуконазол', i:'Дельтаметрин', factor:5, note:'Умеренный синергизм' },
  { f:'Боскалид', i:'Тиаметоксам', factor:7, note:'Ингибирование CYP450' },
  { f:'Азоксистробин', i:'Клотианидин', factor:9, note:'Повышение биодоступности' },
];

// Attach synergy UI in calculator page
function initSynergyCalc() {
  const container = document.getElementById('calc-synergy-content');
  if (!container || container.dataset.inited) return;
  container.dataset.inited = '1';
  const fList = [...new Set(SYNERGY_DATA.map(d=>d.f))];
  const iList = [...new Set(SYNERGY_DATA.map(d=>d.i))];
  container.innerHTML = `
    <div class="grid-2">
      <div class="calc-card">
        <h3 style="margin-bottom:1.2rem;color:var(--c-gold-l)"><i class="fas fa-flask-vial"></i> Оценка синергизма</h3>
        <div class="form-group"><label class="form-label">Фунгицид</label>
          <select id="syn_f" class="form-select">${fList.map(f=>`<option>${f}</option>`).join('')}</select></div>
        <div class="form-group"><label class="form-label">Инсектицид</label>
          <select id="syn_i" class="form-select">${iList.map(i=>`<option>${i}</option>`).join('')}</select></div>
        <div class="form-group"><label class="form-label">Воздействие инсектицида (нг/пчела)</label>
          <input id="syn_exp" class="form-input" type="number" min="0.001" step="0.001" placeholder="2.0"/></div>
        <button class="btn btn-primary" onclick="calcSynergy()" style="width:100%"><i class="fas fa-calculator"></i> Рассчитать синергизм</button>
      </div>
      <div id="syn_result" class="calc-result" style="display:none">
        <h4 style="color:var(--c-gold-l);margin-bottom:1rem">⚗️ Результат</h4>
        <div id="syn_out" style="display:grid;gap:.7rem"></div>
      </div>
    </div>`;
}

function calcSynergy() {
  const f   = document.getElementById('syn_f')?.value;
  const i   = document.getElementById('syn_i')?.value;
  const exp = parseFloat(document.getElementById('syn_exp')?.value) || 0;
  if (!f || !i) return;
  const pair = SYNERGY_DATA.find(d => d.f === f && d.i === i);
  const factor  = pair ? pair.factor : 2; // default ×2 if unknown
  const note    = pair ? pair.note : 'Данные отсутствуют, применён коэффициент ×2';
  const baseLD  = CALC.ld50Data[Object.keys(CALC.ld50Data).find(k=>k.toLowerCase().includes(i.toLowerCase().split(' ')[0]))]?.ld50 || 0.01;
  const effLD   = baseLD / factor;
  const riskRatio = exp > 0 ? (exp / effLD).toFixed(2) : '—';
  const isLethal  = exp > 0 && exp / effLD >= 1;
  document.getElementById('syn_out').innerHTML = `
    <div style="background:var(--c-card);border-radius:var(--r-sm);padding:.8rem 1rem"><div style="font-size:.78rem;color:var(--c-text3)">Пара</div><div style="font-weight:700;color:var(--c-text2)">${f} + ${i}</div></div>
    <div style="background:var(--c-card);border-radius:var(--r-sm);padding:.8rem 1rem"><div style="font-size:.78rem;color:var(--c-text3)">Коэффициент синергизма</div><div style="font-size:1.8rem;font-weight:900;color:${isLethal?'var(--c-red)':'var(--c-gold-l)'}">×${factor}</div></div>
    <div style="background:var(--c-card);border-radius:var(--r-sm);padding:.8rem 1rem"><div style="font-size:.78rem;color:var(--c-text3)">Эффективный LD50</div><div style="font-weight:700;color:var(--c-text)">${effLD.toFixed(4)} мкг/пчела</div></div>
    <div style="background:var(--c-card);border-radius:var(--r-sm);padding:.8rem 1rem"><div style="font-size:.78rem;color:var(--c-text3)">Отношение воздействие/LD50</div><div style="font-size:1.4rem;font-weight:900;color:${isLethal?'var(--c-red)':'var(--c-primary-l)'}">${riskRatio}x ${isLethal?'⚠️ ЛЕТАЛЬНЫЙ':''}</div></div>
    <div style="background:rgba(255,152,0,.08);border:1px solid rgba(255,152,0,.3);border-radius:var(--r-sm);padding:.8rem 1rem;font-size:.82rem;color:var(--c-text2)">💡 ${note}</div>`;
  document.getElementById('syn_result').style.display = 'block';
}

function populateCalcSubstance() {
  const sel = document.getElementById('c_substance');
  if (!sel || sel.options.length > 1) return;
  Object.keys(CALC.ld50Data).forEach(k => {
    const o = document.createElement('option'); o.value = k; o.textContent = k; sel.appendChild(o);
  });
}
function populateCalcCrop() {
  const sel = document.getElementById('c_crop');
  if (!sel || sel.options.length > 1) return;
  Object.keys(CALC.hivesData).forEach(k => {
    const o = document.createElement('option'); o.value = k; o.textContent = k; sel.appendChild(o);
  });
}

// ============================================================
// ===== SECTION 9: CHARTS =====================================
// ============================================================

Chart.defaults.color = '#6fa86f';
Chart.defaults.borderColor = 'rgba(30,68,40,.3)';
Chart.defaults.font.family = "'Inter', sans-serif";

function makeChart(id, config) {
  const ctx = document.getElementById(id);
  if (!ctx || ctx._ci) return;
  ctx._ci = new Chart(ctx, config);
}

function initHomeCharts() {
  makeChart('toxChart', {
    type: 'bar',
    data: {
      labels: ['Неоник.','Пиретр.','ФОС','Карбам.','Фунгиц.','Гербиц.','Акарид.'],
      datasets: [{ label: 'Риск для пчёл (1-10)', data: [9.5,8.5,9,8,3,2,4], backgroundColor: ['rgba(244,67,54,.7)','rgba(255,87,34,.7)','rgba(255,152,0,.7)','rgba(255,193,7,.7)','rgba(76,175,80,.7)','rgba(33,150,243,.7)','rgba(171,71,188,.7)'], borderRadius: 7, borderWidth: 0 }]
    },
    options: { responsive:true, maintainAspectRatio:false, plugins:{ legend:{display:false} }, scales:{ y:{beginAtZero:true,max:10,grid:{color:'rgba(30,68,40,.2)'}}, x:{grid:{display:false}} } }
  });
  makeChart('polChart', {
    type: 'doughnut',
    data: {
      labels: ['Apis mellifera','Bombus spp.','Osmia spp.','Andrena spp.','Halictus/Lasio.'],
      datasets: [{ data:[45,22,18,9,6], backgroundColor:['rgba(249,168,37,.8)','rgba(255,87,34,.8)','rgba(76,175,80,.8)','rgba(33,150,243,.8)','rgba(171,71,188,.8)'], borderColor:'rgba(6,16,10,.5)', borderWidth:2 }]
    },
    options: { responsive:true, maintainAspectRatio:false, plugins:{ legend:{position:'bottom',labels:{padding:10,font:{size:11}}} } }
  });
}

function initPolChart() {
  const months = currentLang==='tk' ? ['Mart','Apr.','Maý','Iýun','Iýul','Awg.','Sent.','Okt.'] :
                 currentLang==='en' ? ['Mar','Apr','May','Jun','Jul','Aug','Sep','Oct'] :
                 ['Март','Апр','Май','Июнь','Июль','Авг','Сент','Окт'];
  makeChart('seasonChart', {
    type:'line',
    data:{ labels:months, datasets:[
      {label:'Apis mellifera',data:[10,80,95,95,90,85,60,20],borderColor:'#ffd54f',backgroundColor:'rgba(255,213,79,.08)',fill:true,tension:.4,borderWidth:2.5,pointRadius:4},
      {label:'Bombus spp.',data:[40,75,80,70,65,60,50,15],borderColor:'#ff7043',backgroundColor:'rgba(255,112,67,.08)',fill:true,tension:.4,borderWidth:2.5,pointRadius:4},
      {label:'Osmia spp.',data:[30,85,80,50,15,5,0,0],borderColor:'#66bb6a',backgroundColor:'rgba(102,187,106,.08)',fill:true,tension:.4,borderWidth:2.5,pointRadius:4},
      {label:'Andrena spp.',data:[5,75,85,30,5,0,0,0],borderColor:'#42a5f5',backgroundColor:'rgba(66,165,245,.08)',fill:true,tension:.4,borderWidth:2.5,pointRadius:4},
      {label:'Lasioglossum',data:[0,20,50,80,90,80,55,10],borderColor:'#ce93d8',backgroundColor:'rgba(206,147,216,.08)',fill:true,tension:.4,borderWidth:2.5,pointRadius:4}
    ]},
    options:{ responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{padding:12,font:{size:11}}}},scales:{ y:{beginAtZero:true,max:100,ticks:{callback:v=>v+'%'},grid:{color:'rgba(30,68,40,.2)'}},x:{grid:{color:'rgba(30,68,40,.1)'}} } }
  });
}

function initFruitChart() {
  makeChart('bloomChart', {
    type:'bar',
    data:{
      labels:['Абрикос','Груша','Слива','Черешня','Яблоня','Вишня','Персик','Нектарин'],
      datasets:[
        {label:'offset',data:[0,0.5,1,1,1,1.5,1,1.5],backgroundColor:'transparent',borderColor:'transparent'},
        {label:'Период цветения (нед.)',data:[4,4,2,4,5,4,6,4],backgroundColor:['rgba(255,152,0,.7)','rgba(76,175,80,.7)','rgba(171,71,188,.7)','rgba(233,30,99,.7)','rgba(33,150,243,.7)','rgba(244,67,54,.7)','rgba(249,168,37,.7)','rgba(255,87,34,.7)'],borderRadius:6,borderWidth:0}
      ]
    },
    options:{ indexAxis:'y',responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{ x:{stacked:true,grid:{color:'rgba(30,68,40,.2)'}},y:{stacked:true,grid:{display:false}} } }
  });
}

function initRisksChart() {
  const substances = ['Дельтаметрин','Λ-цигалотрин','Тиодикарб','Клотианидин','Имидаклоприд','Тиаметоксам','Хлорпирифос','Малатион','Диметоат','Ацетамиприд','Тебуконазол','Глифосат'];
  const vals = [0.001,0.038,0.025,0.0038,0.0037,0.0049,0.059,0.18,0.15,0.0081,25,98];
  makeChart('ld50Chart', {
    type:'bar',
    data:{ labels:substances, datasets:[{ label:'LD50 мкг/пчела', data:vals, backgroundColor:vals.map(v=>v<0.01?'rgba(244,67,54,.75)':v<0.1?'rgba(255,152,0,.75)':v<1?'rgba(255,235,59,.75)':'rgba(76,175,80,.75)'), borderRadius:6, borderWidth:0 }] },
    options:{ responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>`LD50: ${c.raw} мкг/пчела`}}},scales:{ y:{type:'logarithmic',grid:{color:'rgba(30,68,40,.2)'},title:{display:true,text:'LD50 мкг/пчела (лог.)',color:'#6fa86f'}}, x:{grid:{display:false},ticks:{maxRotation:35,font:{size:10}}} } }
  });
}

// ============================================================
// ===== SECTION 10: REFERENCES ================================
// ============================================================

const REFS_DATA = [
  {id:1,authors:'Whitehorn, P.R. et al.',year:2012,title:'Neonicotinoid pesticide reduces bumble bee colony growth and queen production',journal:'Science',doi:'10.1126/science.1215025',tags:['неоник','шмели','Bombus','-85%']},
  {id:2,authors:'Henry, M. et al.',year:2012,title:'A common pesticide decreases foraging success and survival in honey bees',journal:'Science',doi:'10.1126/science.1215039',tags:['тиаметоксам','навигация','GPS']},
  {id:3,authors:'Woodcock, B.A. et al.',year:2017,title:'Country-specific effects of neonicotinoid pesticides on honey bees and wild bees',journal:'Science',doi:'10.1126/science.aaa1190',tags:['неоник','полевые','пчёлы']},
  {id:4,authors:'Motta, E.V.S. et al.',year:2018,title:'Glyphosate perturbs the gut microbiota of honey bees',journal:'PNAS',doi:'10.1073/pnas.1803880115',tags:['глифосат','микробиом','кишечник']},
  {id:5,authors:'Alaux, C. et al.',year:2010,title:'Interactions between Nosema microspores and a neonicotinoid weaken honeybees',journal:'Environmental Microbiology',doi:'10.1111/j.1462-2920.2009.02123.x',tags:['носема','синергизм','иммунитет']},
  {id:6,authors:'EFSA',year:2023,title:'Guidance on the risk assessment of plant protection products on bees (Apis mellifera, Bombus spp. and solitary bees)',journal:'EFSA Journal',doi:'10.2903/j.efsa.2023.8356',tags:['EFSA','риск','методология']},
  {id:7,authors:'Garratt, M.P.D. et al.',year:2014,title:'The identity and importance of pollinator species to UK apples',journal:'Ecology and Evolution',doi:'10.1002/ece3.1043',tags:['яблоня','опылители','+26%']},
  {id:8,authors:'Klein, A.-M. et al.',year:2007,title:'Importance of pollinators in changing landscapes for world crops',journal:'Proceedings of the Royal Society B',doi:'10.1098/rspb.2006.3721',tags:['урожай','мировые культуры']},
  {id:9,authors:'Desneux, N. et al.',year:2007,title:'The sublethal effects of pesticides on beneficial arthropods',journal:'Annual Review of Entomology',doi:'10.1146/annurev.ento.52.110405.091440',tags:['сублетальные','поведение']},
  {id:10,authors:'Johnson, R.M. et al.',year:2013,title:'Pesticide synergies and their effects on brood and adult honey bees',journal:'PLOS ONE',doi:'10.1371/journal.pone.0072108',tags:['синергизм','фунгициды']},
  {id:11,authors:'Gallai, N. et al.',year:2009,title:'Economic valuation of the vulnerability of world agriculture confronted with pollinator decline',journal:'Ecological Economics',doi:'10.1016/j.ecolecon.2008.10.014',tags:['экономика','$153 млрд']},
  {id:12,authors:'FAO',year:2020,title:"State of the World's Biodiversity for Food and Agriculture",journal:'FAO Commission on Genetic Resources',doi:'',tags:['FAO','биоразнообразие','ЦА']},
  {id:13,authors:'Ollerton, J. et al.',year:2011,title:'How many flowering plants are pollinated by animals?',journal:'Oikos',doi:'10.1111/j.1600-0706.2010.18644.x',tags:['опыление','87%']},
  {id:14,authors:'Vanbergen, A.J. et al.',year:2013,title:'Threats to an ecosystem service: pressures on pollinators',journal:'Frontiers in Ecology',doi:'10.1890/120126',tags:['угрозы','экосистема']},
  {id:15,authors:'Stoner, K.A. & Eitzer, B.D.',year:2012,title:'Movement of soil-applied imidacloprid and thiamethoxam into nectar and pollen',journal:'PLOS ONE',doi:'10.1371/journal.pone.0039114',tags:['нектар','пыльца','системный']},
];

function renderRefs() { filterRefs(); }

function filterRefs() {
  const q   = (document.getElementById('refSearch')?.value||'').toLowerCase();
  const box = document.getElementById('refList');
  if (!box) return;
  const filtered = REFS_DATA.filter(r => {
    const txt = `${r.authors} ${r.year} ${r.title} ${r.journal} ${r.tags.join(' ')}`.toLowerCase();
    return !q || txt.includes(q);
  });
  if (!filtered.length) { box.innerHTML = `<p style="text-align:center;color:var(--c-text3);padding:3rem">...</p>`; return; }
  box.innerHTML = filtered.map(r=>`<div class="card card-stripe" style="margin-bottom:.8rem;padding:1.1rem 1.4rem">
    <div style="display:flex;gap:1rem">
      <div style="background:var(--c-bg3);border-radius:var(--r-sm);padding:.35rem .65rem;font-size:.82rem;font-weight:700;color:var(--c-gold-l);flex-shrink:0">[${r.id}]</div>
      <div style="flex:1">
        <p style="color:var(--c-text);font-weight:700;margin-bottom:.2rem;font-size:.93rem">${r.title}</p>
        <p style="color:var(--c-text2);font-size:.82rem">${r.authors} · <em>${r.journal}</em> · ${r.year}</p>
        ${r.doi?`<a href="https://doi.org/${r.doi}" target="_blank" style="color:var(--c-primary-l);font-size:.78rem;text-decoration:none">DOI: ${r.doi} ↗</a>`:''}
        <div style="margin-top:.4rem">${r.tags.map(tg=>`<span class="tag tag-green" style="font-size:.7rem">${tg}</span>`).join('')}</div>
      </div>
    </div>
  </div>`).join('');
}

// ============================================================
// ===== SECTION 11: ACCORDION & TABS ==========================
// ============================================================

function toggleAcc(header) {
  const item = header.closest('.acc-item');
  const wasOpen = item.classList.contains('open');
  item.closest('section, .page')?.querySelectorAll('.acc-item').forEach(i=>i.classList.remove('open'));
  if (!wasOpen) item.classList.add('open');
}
function openTab(btn, paneId) {
  const container = btn.closest('.page, .card, .calc-card, [id^="page-"]');
  container?.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  container?.querySelectorAll('.tab-pane').forEach(p=>p.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById(paneId)?.classList.add('active');
}

// ============================================================
// ===== SECTION 12: UTILS =====================================
// ============================================================

function showToast(msg, duration=3000) {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(()=>{ toast.style.opacity='0'; toast.style.transition='opacity .3s'; setTimeout(()=>toast.remove(),300); }, duration);
}

function initParticles() {
  const c = document.getElementById('heroCanvas');
  if (!c) return;
  const ctx2 = c.getContext('2d');
  c.width = c.offsetWidth; c.height = c.offsetHeight;
  const pts = Array.from({length:40},()=>({ x:Math.random()*c.width, y:Math.random()*c.height, vx:(Math.random()-.5)*.4, vy:(Math.random()-.5)*.4, r:Math.random()*2+1, o:Math.random()*.4+.1 }));
  function draw(){
    ctx2.clearRect(0,0,c.width,c.height);
    pts.forEach(p=>{ p.x+=p.vx; p.y+=p.vy; if(p.x<0)p.x=c.width; if(p.x>c.width)p.x=0; if(p.y<0)p.y=c.height; if(p.y>c.height)p.y=0; ctx2.beginPath(); ctx2.arc(p.x,p.y,p.r,0,Math.PI*2); ctx2.fillStyle=`rgba(76,175,80,${p.o})`; ctx2.fill(); });
    requestAnimationFrame(draw);
  }
  draw();
  window.addEventListener('resize',()=>{ c.width=c.offsetWidth; c.height=c.offsetHeight; });
}

function copyCode(text) {
  navigator.clipboard.writeText(text).then(()=>showToast(t('copied')));
}

// PWA install
let deferredPWA;
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredPWA = e; document.getElementById('installBanner').style.display='block'; });
function installPWA() { if(!deferredPWA) return; deferredPWA.prompt(); deferredPWA.userChoice.then(r=>{ if(r.outcome==='accepted') document.getElementById('installBanner').style.display='none'; deferredPWA=null; }); }

window.addEventListener('online',  ()=>showToast(t('online_msg')));
window.addEventListener('offline', ()=>showToast(t('offline_msg'), 5000));

// Service Worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', ()=>{ navigator.serviceWorker.register('sw.js').catch(()=>{}); });
}

// ============================================================
// ===== SECTION 13: INIT ======================================
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  // Инициализируем данные
  ARCHIVE.seedDefaults();

  // Применяем язык
  applyTranslations();
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.toggle('active', b.dataset.lang === currentLang));

  // Обновляем аутентификацию
  updateNavAuth();

  // Частицы
  initParticles();

  // Инициализируем первую страницу
  setTimeout(initHomeCharts, 400);

  // Параметры URL
  const params = new URLSearchParams(window.location.search);
  const pg = params.get('page');
  if (pg) showPage(pg);

  // Закрытие мобильного меню
  document.addEventListener('click', e => {
    if (!e.target.closest('.nav-center') && !e.target.closest('.hamburger')) {
      document.querySelector('.nav-center')?.classList.remove('open');
    }
  });

  // ESC
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay').forEach(m=>m.classList.remove('open'));
      document.querySelector('.nav-center')?.classList.remove('open');
    }
  });

  // Заполняем селекты калькулятора
  populateCalcSubstance();
  populateCalcCrop();

  console.log('%c🌱 ÖŇDE BARYJY ÝYLADYŞHANA', 'color:#4caf50;font-size:16px;font-weight:bold');
  console.log('%cAuthor: yesenow dayanc | PWA | i18n: RU/EN/TK', 'color:#ffd54f');
});
