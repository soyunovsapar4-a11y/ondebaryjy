// ============================================================
// ПчелоАгро ЦА — Main JavaScript
// ============================================================

// ===== NAVIGATION =====
function showPage(pageName) {
  // Скрываем все страницы
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  // Показываем нужную
  const target = document.getElementById('page-' + pageName);
  if (target) {
    target.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  // Обновляем активную ссылку
  document.querySelectorAll('.nav-links a').forEach(a => {
    a.classList.remove('active');
    if (a.dataset.page === pageName) a.classList.add('active');
  });
  // Закрываем мобильное меню
  document.getElementById('navLinks').classList.remove('open');

  // Инициализируем графики при первом показе
  if (pageName === 'home' && !window._homeInit) {
    window._homeInit = true;
    setTimeout(initHomeCharts, 200);
  }
  if (pageName === 'pollinators' && !window._polInit) {
    window._polInit = true;
    setTimeout(initPollinatorChart, 200);
  }
  if (pageName === 'fruits' && !window._fruitsInit) {
    window._fruitsInit = true;
    setTimeout(initFruitCharts, 200);
  }
  if (pageName === 'risks' && !window._risksInit) {
    window._risksInit = true;
    setTimeout(initRisksCharts, 200);
  }
  if (pageName === 'recommendations' && !window._recInit) {
    window._recInit = true;
    renderChecklist();
  }
  if (pageName === 'references' && !window._refInit) {
    window._refInit = true;
    renderReferences();
  }
}

// ===== HAMBURGER MENU =====
function toggleMenu() {
  document.getElementById('navLinks').classList.toggle('open');
}

// ===== ACCORDION =====
function toggleAccordion(header) {
  const item = header.closest('.accordion-item');
  const isOpen = item.classList.contains('open');
  // Закрыть все в том же контейнере
  const parent = item.parentElement;
  parent.querySelectorAll('.accordion-item').forEach(i => i.classList.remove('open'));
  if (!isOpen) item.classList.add('open');
}

// ===== TABS =====
function openTab(btn, tabId) {
  const container = btn.closest('.page');
  container.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  container.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  btn.classList.add('active');
  const el = document.getElementById(tabId);
  if (el) el.classList.add('active');
}

// ===== PARTICLES ANIMATION =====
function initParticles() {
  const container = document.getElementById('particles');
  if (!container) return;
  const emojis = ['🐝','🌸','🌼','🌻','🍎','🌿','🍐','🌺'];
  for (let i = 0; i < 18; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    const size = Math.random() * 30 + 15;
    p.style.cssText = `
      width: ${size}px;
      height: ${size}px;
      left: ${Math.random() * 100}%;
      animation-duration: ${Math.random() * 12 + 8}s;
      animation-delay: ${Math.random() * 10}s;
      font-size: ${size}px;
      background: transparent;
      display: flex;
      align-items: center;
      justify-content: center;
    `;
    p.textContent = emojis[Math.floor(Math.random() * emojis.length)];
    container.appendChild(p);
  }
}

// ===== CHART.JS DEFAULTS =====
function setChartDefaults() {
  if (!window.Chart) return;
  Chart.defaults.color = '#a5d6a7';
  Chart.defaults.borderColor = 'rgba(46,125,50,0.2)';
  Chart.defaults.font.family = "'Inter', 'Segoe UI', Arial, sans-serif";
}

// ===== HOME CHARTS =====
function initHomeCharts() {
  if (!window.Chart) return;

  // 1. Токсичность классов
  const toxCtx = document.getElementById('toxChart');
  if (toxCtx && !toxCtx._chartInstance) {
    toxCtx._chartInstance = new Chart(toxCtx, {
      type: 'bar',
      data: {
        labels: ['Неоникотиноиды', 'Пиретроиды', 'ФОС', 'Карбаматы', 'Фунгициды', 'Гербициды', 'Акарициды'],
        datasets: [{
          label: 'Уровень риска для пчёл (1–10)',
          data: [9.5, 8.5, 9, 8, 3, 2, 4],
          backgroundColor: [
            'rgba(244,67,54,0.7)', 'rgba(255,87,34,0.7)', 'rgba(255,152,0,0.7)',
            'rgba(255,193,7,0.7)', 'rgba(76,175,80,0.7)', 'rgba(33,150,243,0.7)',
            'rgba(156,39,176,0.7)'
          ],
          borderColor: [
            '#f44336','#ff5722','#ff9800','#ffc107','#4caf50','#2196f3','#9c27b0'
          ],
          borderWidth: 1.5,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => `Риск: ${ctx.raw}/10`
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true, max: 10,
            grid: { color: 'rgba(46,125,50,0.15)' },
            ticks: { color: '#a5d6a7' }
          },
          x: {
            grid: { display: false },
            ticks: { color: '#a5d6a7', maxRotation: 30 }
          }
        }
      }
    });
  }

  // 2. Эффективность опылителей
  const polCtx = document.getElementById('polChart');
  if (polCtx && !polCtx._chartInstance) {
    polCtx._chartInstance = new Chart(polCtx, {
      type: 'doughnut',
      data: {
        labels: ['Apis mellifera', 'Bombus spp.', 'Osmia spp.', 'Andrena spp.', 'Halictus/Lasio.'],
        datasets: [{
          data: [45, 22, 18, 9, 6],
          backgroundColor: [
            'rgba(249,168,37,0.8)', 'rgba(255,87,34,0.8)', 'rgba(76,175,80,0.8)',
            'rgba(33,150,243,0.8)', 'rgba(156,39,176,0.8)'
          ],
          borderColor: 'rgba(13,27,15,0.5)',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#a5d6a7', padding: 10, font: { size: 11 } }
          },
          tooltip: {
            callbacks: {
              label: ctx => `${ctx.label}: ${ctx.raw}% визитов`
            }
          }
        }
      }
    });
  }
}

// ===== POLLINATOR CHART =====
function initPollinatorChart() {
  if (!window.Chart) return;
  const ctx = document.getElementById('seasonChart');
  if (!ctx || ctx._chartInstance) return;

  const months = ['Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь'];
  ctx._chartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: months,
      datasets: [
        {
          label: 'Apis mellifera',
          data: [10, 80, 95, 95, 90, 85, 60, 20],
          borderColor: '#ffd54f', backgroundColor: 'rgba(255,213,79,0.1)',
          fill: true, tension: 0.4, borderWidth: 2.5, pointRadius: 4
        },
        {
          label: 'Bombus spp.',
          data: [40, 75, 80, 70, 65, 60, 50, 15],
          borderColor: '#ff7043', backgroundColor: 'rgba(255,112,67,0.1)',
          fill: true, tension: 0.4, borderWidth: 2.5, pointRadius: 4
        },
        {
          label: 'Osmia spp.',
          data: [30, 85, 80, 50, 15, 5, 0, 0],
          borderColor: '#66bb6a', backgroundColor: 'rgba(102,187,106,0.1)',
          fill: true, tension: 0.4, borderWidth: 2.5, pointRadius: 4
        },
        {
          label: 'Andrena spp.',
          data: [5, 75, 85, 30, 5, 0, 0, 0],
          borderColor: '#42a5f5', backgroundColor: 'rgba(66,165,245,0.1)',
          fill: true, tension: 0.4, borderWidth: 2.5, pointRadius: 4
        },
        {
          label: 'Lasioglossum/Halictus',
          data: [0, 20, 50, 80, 90, 80, 55, 10],
          borderColor: '#ce93d8', backgroundColor: 'rgba(206,147,216,0.1)',
          fill: true, tension: 0.4, borderWidth: 2.5, pointRadius: 4
        }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: '#a5d6a7', padding: 12, font: { size: 11 } }
        },
        tooltip: {
          callbacks: {
            label: ctx => `${ctx.dataset.label}: ${ctx.raw}% активности`
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true, max: 100,
          grid: { color: 'rgba(46,125,50,0.15)' },
          ticks: { color: '#a5d6a7', callback: v => v + '%' }
        },
        x: {
          grid: { color: 'rgba(46,125,50,0.1)' },
          ticks: { color: '#a5d6a7' }
        }
      }
    }
  });
}

// ===== FRUIT CHARTS =====
function initFruitCharts() {
  if (!window.Chart) return;
  const ctx = document.getElementById('bloomChart');
  if (!ctx || ctx._chartInstance) return;

  // Ганта-подобный: начало и длительность цветения
  const crops = ['Абрикос', 'Груша', 'Слива', 'Черешня', 'Яблоня', 'Вишня', 'Персик', 'Нектарин'];
  // [начало месяц (1=янв), конец месяц]
  const data = [
    [3, 4], [3.5, 4.5], [4, 4.5], [4, 5], [4, 5.2], [4.5, 5.5], [4, 5.5], [4.5, 5.5]
  ];

  ctx._chartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: crops,
      datasets: [
        {
          label: 'Начало цветения (смещение)',
          data: data.map(d => d[0] - 3),
          backgroundColor: 'transparent',
          borderColor: 'transparent'
        },
        {
          label: 'Период цветения (нед.)',
          data: data.map(d => (d[1] - d[0]) * 4),
          backgroundColor: [
            'rgba(255,152,0,0.7)', 'rgba(76,175,80,0.7)', 'rgba(156,39,176,0.7)',
            'rgba(233,30,99,0.7)', 'rgba(33,150,243,0.7)', 'rgba(244,67,54,0.7)',
            'rgba(249,168,37,0.7)', 'rgba(255,87,34,0.7)'
          ],
          borderRadius: 6,
          borderWidth: 0
        }
      ]
    },
    options: {
      indexAxis: 'y',
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => {
              if (ctx.datasetIndex === 1) {
                const crop = crops[ctx.dataIndex];
                const d = data[ctx.dataIndex];
                const months = ['', 'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь'];
                return `Цветение: ${months[Math.floor(d[0])]} – ${months[Math.ceil(d[1])]}`;
              }
              return null;
            }
          }
        }
      },
      scales: {
        x: {
          stacked: true,
          grid: { color: 'rgba(46,125,50,0.15)' },
          ticks: {
            color: '#a5d6a7',
            callback: v => {
              const labels = ['Март', '', 'Апрель', '', 'Май'];
              return labels[v] || '';
            }
          }
        },
        y: {
          stacked: true,
          grid: { display: false },
          ticks: { color: '#a5d6a7', font: { size: 12 } }
        }
      }
    }
  });
}

// ===== RISKS CHART =====
function initRisksCharts() {
  if (!window.Chart) return;
  const ctx = document.getElementById('ld50Chart');
  if (!ctx || ctx._chartInstance) return;

  const substances = [
    'Дельтаметрин', 'Λ-цигалотрин', 'Тиодикарб', 'Клотианидин',
    'Имидаклоприд', 'Тиаметоксам', 'Хлорпирифос', 'Малатион',
    'Диметоат', 'Ацетамиприд', 'Тебуконазол', 'Глифосат'
  ];
  const ld50Values = [0.001, 0.038, 0.025, 0.0038, 0.0037, 0.0049, 0.059, 0.18, 0.15, 0.0081, 25, 98];
  const colors = substances.map((_, i) => {
    const v = ld50Values[i];
    if (v < 0.01) return 'rgba(244,67,54,0.8)';
    if (v < 0.1) return 'rgba(255,152,0,0.8)';
    if (v < 1) return 'rgba(255,235,59,0.8)';
    return 'rgba(76,175,80,0.8)';
  });

  ctx._chartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: substances,
      datasets: [{
        label: 'LD50 (мкг/пчела)',
        data: ld50Values,
        backgroundColor: colors,
        borderWidth: 0,
        borderRadius: 6
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: ctx => `LD50: ${ctx.raw} мкг/пчела${ctx.raw < 0.01 ? ' ⚠️ КРИТИЧНО' : ''}`
          }
        }
      },
      scales: {
        y: {
          type: 'logarithmic',
          grid: { color: 'rgba(46,125,50,0.15)' },
          ticks: {
            color: '#a5d6a7',
            callback: v => v < 0.01 ? v.toFixed(4) : (v < 1 ? v.toFixed(3) : v)
          },
          title: { display: true, text: 'LD50 мкг/пчела (лог. шкала)', color: '#a5d6a7' }
        },
        x: {
          grid: { display: false },
          ticks: { color: '#a5d6a7', maxRotation: 35, font: { size: 10 } }
        }
      }
    }
  });
}

// ===== CHECKLIST =====
const checklistItems = [
  { text: 'Проверить погоду: нет дождя, ветер <3 м/с, температура <15°C ночью', category: 'before' },
  { text: 'Уточнить фазу цветения культур в радиусе 3 км', category: 'before' },
  { text: 'Уведомить всех пчеловодов в радиусе 3 км за 48+ часов', category: 'before' },
  { text: 'Прочитать этикетку препарата: класс опасности для пчёл', category: 'before' },
  { text: 'Выбрать время: 22:00–06:00 (пчёлы в улье)', category: 'timing' },
  { text: 'При использовании неоникотиноидов — только вне периода цветения (±14 дней)', category: 'timing' },
  { text: 'Исключить обработку рядом цветущих сорняков', category: 'timing' },
  { text: 'Используйте минимально эффективную норму расхода', category: 'dosage' },
  { text: 'Предпочитайте гранулы и капсулы вместо распыления', category: 'dosage' },
  { text: 'Не смешивайте фунгициды+инсектициды без проверки синергизма', category: 'dosage' },
  { text: 'Оставить необработанные полосы как убежище для опылителей', category: 'habitat' },
  { text: 'Сохранять цветущие края полей и живые изгороди', category: 'habitat' },
  { text: 'Вести журнал обработок с датами, препаратами и погодой', category: 'record' },
  { text: 'Наблюдать за гибелью пчёл в течение 48 ч после обработки', category: 'record' },
  { text: 'При массовой гибели: уведомить ветеринарную службу, сохранить образцы', category: 'record' }
];

const catLabels = {
  before: '🔍 До обработки',
  timing: '⏰ Время обработки',
  dosage: '💊 Дозировка и препараты',
  habitat: '🌿 Защита среды обитания',
  record: '📝 Документирование'
};

function renderChecklist() {
  const container = document.getElementById('checklist');
  if (!container) return;

  const cats = [...new Set(checklistItems.map(i => i.category))];
  let html = '';
  cats.forEach(cat => {
    html += `<div style="margin-bottom:1.5rem">
      <h4 style="color:var(--secondary-light);margin-bottom:0.8rem;font-size:0.95rem">${catLabels[cat]}</h4>`;
    checklistItems.filter(i => i.category === cat).forEach((item, idx) => {
      const id = `chk_${cat}_${idx}`;
      html += `<label for="${id}" style="display:flex;align-items:flex-start;gap:0.8rem;padding:0.6rem 0.8rem;border-radius:8px;cursor:pointer;transition:background 0.2s;margin-bottom:0.3rem" 
        onmouseover="this.style.background='rgba(76,175,80,0.08)'" onmouseout="this.style.background=''" >
        <input type="checkbox" id="${id}" style="margin-top:0.2rem;accent-color:var(--primary-light);width:16px;height:16px;flex-shrink:0" onchange="updateChecklistProgress()" />
        <span style="color:var(--text-muted);font-size:0.9rem;line-height:1.5">${item.text}</span>
      </label>`;
    });
    html += '</div>';
  });

  html += `<div id="checklistProgress" style="margin-top:1.5rem;padding:1rem 1.5rem;background:var(--bg-card);border-radius:var(--radius);border:1px solid var(--border)">
    <div style="display:flex;justify-content:space-between;margin-bottom:0.5rem">
      <span style="color:var(--text-muted);font-size:0.9rem">Выполнено:</span>
      <span id="checkCount" style="color:var(--secondary-light);font-weight:700">0 / ${checklistItems.length}</span>
    </div>
    <div class="progress-bar"><div id="checkFill" class="progress-fill" style="width:0%;transition:width 0.3s ease"></div></div>
  </div>`;

  container.innerHTML = html;
}

function updateChecklistProgress() {
  const total = checklistItems.length;
  const checked = document.querySelectorAll('#checklist input[type=checkbox]:checked').length;
  document.getElementById('checkCount').textContent = `${checked} / ${total}`;
  document.getElementById('checkFill').style.width = `${(checked/total)*100}%`;
}

// ===== REFERENCES =====
const referencesData = [
  {
    id: 1,
    authors: 'Garratt, M.P.D. et al.',
    year: 2014,
    title: 'The identity and importance of pollinator species to UK apples',
    journal: 'Ecology and Evolution',
    doi: '10.1002/ece3.1043',
    tags: ['яблоня', 'опылители', 'UK', 'завязь']
  },
  {
    id: 2,
    authors: 'Albano, S. et al.',
    year: 2009,
    title: 'Bee fauna in apple orchards and its impact on fruit set',
    journal: 'Apidologie',
    doi: '10.1051/apido/2008072',
    tags: ['яблоня', 'шмели', 'завязь', '+15%']
  },
  {
    id: 3,
    authors: 'Kevan, P.G. & Baker, H.G.',
    year: 1983,
    title: 'Insects as flower visitors and pollinators',
    journal: 'Annual Review of Entomology',
    doi: '10.1146/annurev.en.28.010183.002235',
    tags: ['опылители', 'обзор', 'классика']
  },
  {
    id: 4,
    authors: 'Monck, S.L. et al.',
    year: 2013,
    title: 'Osmia bicornis as a complement to Apis mellifera in apple orchards',
    journal: 'Agricultural and Forest Entomology',
    doi: '10.1111/afe.12020',
    tags: ['осмии', 'яблоня', 'Osmia', 'плохая погода']
  },
  {
    id: 5,
    authors: 'Whitehorn, P.R. et al.',
    year: 2012,
    title: 'Neonicotinoid pesticide reduces bumble bee colony growth and queen production',
    journal: 'Science',
    doi: '10.1126/science.1215025',
    tags: ['неоникотиноиды', 'шмели', 'имидаклоприд', 'репродукция', '-85%']
  },
  {
    id: 6,
    authors: 'Woodcock, B.A. et al.',
    year: 2017,
    title: 'Country-specific effects of neonicotinoid pesticides on honey bees and wild bees',
    journal: 'Science',
    doi: '10.1126/science.aaa1190',
    tags: ['неоникотиноиды', 'тиаметоксам', 'пчёлы', 'шмели', 'полевые условия']
  },
  {
    id: 7,
    authors: 'Henry, M. et al.',
    year: 2012,
    title: 'A common pesticide decreases foraging success and survival in honey bees',
    journal: 'Science',
    doi: '10.1126/science.1215039',
    tags: ['тиаметоксам', 'навигация', 'сбор нектара', 'GPS']
  },
  {
    id: 8,
    authors: 'Desneux, N. et al.',
    year: 2007,
    title: 'The sublethal effects of pesticides on beneficial arthropods',
    journal: 'Annual Review of Entomology',
    doi: '10.1146/annurev.ento.52.110405.091440',
    tags: ['сублетальные', 'пестициды', 'поведение', 'обзор']
  },
  {
    id: 9,
    authors: 'Motta, E.V.S. et al.',
    year: 2018,
    title: 'Glyphosate perturbs the gut microbiota of honey bees',
    journal: 'PNAS',
    doi: '10.1073/pnas.1803880115',
    tags: ['глифосат', 'микробиота', 'кишечник', 'Apis']
  },
  {
    id: 10,
    authors: 'Alaux, C. et al.',
    year: 2010,
    title: 'Interactions between Nosema microspores and a neonicotinoid weaken honeybees',
    journal: 'Environmental Microbiology',
    doi: '10.1111/j.1462-2920.2009.02123.x',
    tags: ['носема', 'имидаклоприд', 'синергизм', 'иммунитет']
  },
  {
    id: 11,
    authors: 'Pilling, E.D. et al.',
    year: 1995,
    title: 'The effect of difenoconazole on the detoxification of insecticides by honey bees',
    journal: 'Pesticide Science',
    doi: '10.1002/ps.2780430102',
    tags: ['фунгициды', 'синергизм', 'CYP450', 'детоксикация']
  },
  {
    id: 12,
    authors: 'Johnson, R.M. et al.',
    year: 2013,
    title: 'Pesticide synergies and their effects on brood and adult honey bees',
    journal: 'PLOS ONE',
    doi: '10.1371/journal.pone.0072108',
    tags: ['синергизм', 'фунгициды', 'LD50', 'пестициды']
  },
  {
    id: 13,
    authors: 'EFSA',
    year: 2013,
    title: 'Guidance on the risk assessment of plant protection products on bees',
    journal: 'EFSA Journal',
    doi: '10.2903/j.efsa.2013.3295',
    tags: ['EFSA', 'регуляция', 'риск', 'методология']
  },
  {
    id: 14,
    authors: 'Vanbergen, A.J. et al.',
    year: 2013,
    title: 'Threats to an ecosystem service: pressures on pollinators',
    journal: 'Frontiers in Ecology and the Environment',
    doi: '10.1890/120126',
    tags: ['угрозы', 'опылители', 'экосистемные услуги', 'обзор']
  },
  {
    id: 15,
    authors: 'FAO',
    year: 2020,
    title: 'State of the World\'s Biodiversity for Food and Agriculture',
    journal: 'FAO Commission on Genetic Resources',
    doi: '',
    tags: ['FAO', 'биоразнообразие', 'сельское хозяйство', 'ЦА']
  },
  {
    id: 16,
    authors: 'Ollerton, J. et al.',
    year: 2011,
    title: 'How many flowering plants are pollinated by animals?',
    journal: 'Oikos',
    doi: '10.1111/j.1600-0706.2010.18644.x',
    tags: ['опыление', 'цветковые', 'обзор', '87%']
  },
  {
    id: 17,
    authors: 'Gallai, N. et al.',
    year: 2009,
    title: 'Economic valuation of the vulnerability of world agriculture confronted with pollinator decline',
    journal: 'Ecological Economics',
    doi: '10.1016/j.ecolecon.2008.10.014',
    tags: ['экономика', 'опылители', 'сельское хозяйство', '$153 млрд']
  },
  {
    id: 18,
    authors: 'Klein, A.-M. et al.',
    year: 2007,
    title: 'Importance of pollinators in changing landscapes for world crops',
    journal: 'Proceedings of the Royal Society B',
    doi: '10.1098/rspb.2006.3721',
    tags: ['урожай', 'опыление', 'мировые культуры', 'обзор']
  },
  {
    id: 19,
    authors: 'Потлайчук, В.И.',
    year: 2021,
    title: 'Применение пестицидов в садоводстве Центральной Азии: обзор',
    journal: 'Агрохимия',
    doi: '',
    tags: ['ЦА', 'садоводство', 'пестициды', 'обзор']
  },
  {
    id: 20,
    authors: 'Stoner, K.A. & Eitzer, B.D.',
    year: 2012,
    title: 'Movement of soil-applied imidacloprid and thiamethoxam into nectar and pollen',
    journal: 'PLOS ONE',
    doi: '10.1371/journal.pone.0039114',
    tags: ['имидаклоприд', 'нектар', 'пыльца', 'системность']
  }
];

function renderReferences() {
  filterRefs();
}

function filterRefs() {
  const q = (document.getElementById('refSearch')?.value || '').toLowerCase();
  const container = document.getElementById('refList');
  if (!container) return;

  const filtered = referencesData.filter(r => {
    const text = `${r.authors} ${r.year} ${r.title} ${r.journal} ${r.tags.join(' ')}`.toLowerCase();
    return !q || text.includes(q);
  });

  if (filtered.length === 0) {
    container.innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:3rem">Ничего не найдено</p>';
    return;
  }

  let html = `<p style="color:var(--text-muted);font-size:0.85rem;margin-bottom:1rem">Найдено: ${filtered.length} источников</p>`;
  filtered.forEach(r => {
    html += `<div class="card" style="margin-bottom:0.8rem;padding:1.2rem 1.5rem">
      <div style="display:flex;gap:1rem;align-items:flex-start">
        <div style="background:var(--primary-dark);border-radius:8px;padding:0.4rem 0.7rem;font-size:0.85rem;font-weight:700;color:var(--secondary-light);flex-shrink:0">[${r.id}]</div>
        <div style="flex:1">
          <p style="color:var(--text-main);font-weight:600;margin-bottom:0.2rem;font-size:0.95rem">${r.title}</p>
          <p style="color:var(--text-muted);font-size:0.85rem">${r.authors} · <em>${r.journal}</em> · ${r.year}</p>
          ${r.doi ? `<a href="https://doi.org/${r.doi}" target="_blank" rel="noopener" style="color:var(--primary-light);font-size:0.8rem;text-decoration:none">DOI: ${r.doi} ↗</a>` : ''}
          <div style="margin-top:0.5rem">${r.tags.map(t => `<span class="tag tag-info" style="font-size:0.72rem">${t}</span>`).join('')}</div>
        </div>
      </div>
    </div>`;
  });

  container.innerHTML = html;
}

// ===== PWA INSTALL =====
let deferredPrompt;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  document.getElementById('installBanner').style.display = 'block';
});

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('installBtn');
  if (btn) {
    btn.addEventListener('click', async () => {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        document.getElementById('installBanner').style.display = 'none';
      }
      deferredPrompt = null;
    });
  }
});

// ===== INTERSECTION OBSERVER (анимации) =====
function initObserver() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.style.opacity = '1';
        e.target.style.transform = 'translateY(0)';
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.card, .timeline-item, .species-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    observer.observe(el);
  });
}

// ===== URL ПАРАМЕТРЫ (для SEO) =====
function parseURLParams() {
  const params = new URLSearchParams(window.location.search);
  const page = params.get('page');
  const search = params.get('search');
  if (page) showPage(page);
  if (search && page === 'references') {
    const el = document.getElementById('refSearch');
    if (el) { el.value = search; filterRefs(); }
  }
}

// ===== ИНИЦИАЛИЗАЦИЯ =====
document.addEventListener('DOMContentLoaded', () => {
  setChartDefaults();
  initParticles();
  parseURLParams();

  // Инициализируем первую страницу
  setTimeout(() => {
    initHomeCharts();
    initObserver();
  }, 300);

  // Закрытие меню при клике вне его
  document.addEventListener('click', (e) => {
    const nav = document.getElementById('navLinks');
    const ham = document.getElementById('hamburger');
    if (!nav.contains(e.target) && !ham.contains(e.target)) {
      nav.classList.remove('open');
    }
  });

  // Keyboard навигация
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.getElementById('navLinks').classList.remove('open');
    }
  });
});

// ===== ONLINE/OFFLINE СТАТУС =====
window.addEventListener('online', () => {
  console.log('ПчелоАгро ЦА: соединение восстановлено');
});
window.addEventListener('offline', () => {
  console.log('ПчелоАгро ЦА: работа в офлайн режиме (PWA)');
  // Можно показать уведомление
  const notice = document.createElement('div');
  notice.style.cssText = 'position:fixed;top:70px;left:50%;transform:translateX(-50%);background:#333;color:#fff;padding:0.6rem 1.2rem;border-radius:50px;font-size:0.85rem;z-index:9999;opacity:0;transition:opacity 0.3s';
  notice.textContent = '📵 Офлайн режим — данные загружены из кэша';
  document.body.appendChild(notice);
  setTimeout(() => notice.style.opacity = '1', 100);
  setTimeout(() => { notice.style.opacity = '0'; setTimeout(() => notice.remove(), 400); }, 3000);
});
